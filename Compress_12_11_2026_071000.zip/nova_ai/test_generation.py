
import sys
from pathlib import Path
import numpy as np

ROOT = Path("/storage/emulated/0/nova_ai/nova2")
sys.path.insert(0, str(ROOT))

import nova_engine

print("MODULE:", nova_engine.__file__)
print("CLASS EXISTS:", hasattr(nova_engine, "NovaEngine"))

NovaEngine = nova_engine.NovaEngine
nova = NovaEngine()

tests = [
    "привет",
    "NOVA AI",
    "искусственный интеллект"
]

print("\nNOVA AI — GENERATION DIAGNOSTICS")

for prompt in tests:
    tokens = nova.tokenizer.encode(prompt)
    initial_length = len(tokens)

    print("\nPROMPT:", prompt)

    for _ in range(30):
        context = tokens[-128:]

        probabilities = nova.model.predict(
            np.asarray(context, dtype=np.int64)
        )

        tokens.append(int(np.argmax(probabilities)))

    result = nova.tokenizer.decode(
        tokens[initial_length:]
    )

    print("GREEDY:", result)

print("\nDIAGNOSTICS COMPLETE")
