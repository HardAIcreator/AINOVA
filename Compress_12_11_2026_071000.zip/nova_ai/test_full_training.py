import sys
sys.path.insert(0, "/storage/emulated/0/nova_ai/nova2")

import numpy as np
from model.language_model import LanguageModel
from model.training import OutputTrainer

model = LanguageModel(
    vocab_size=50,
    embed_size=64,
    hidden_size=256,
    num_layers=2
)

trainer = OutputTrainer(learning_rate=0.001)

tokens = np.array([1, 2, 3, 4, 5])
targets = np.array([2, 3, 4, 5, 6])

before = model.embeddings.weights.copy()
before_attention = model.blocks[0].attention.Wq.copy()

loss = trainer.train_step(tokens, targets, model)

print("NOVA AI — FULL TRAINING TEST")
print("Loss:", loss)
print("Embeddings обновлены:",
      not np.array_equal(before, model.embeddings.weights))
print("Attention обновлён:",
      not np.array_equal(before_attention,
                         model.blocks[0].attention.Wq))
print("Loss конечный:", np.isfinite(loss))
print("TEST COMPLETE")