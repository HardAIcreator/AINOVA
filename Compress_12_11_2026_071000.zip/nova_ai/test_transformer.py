import sys
import os
import numpy as np

ROOT = "/storage/emulated/0/nova_ai/nova2"
sys.path.insert(0, ROOT)

from model.tokenizer import BPETokenizer
from model.embeddings import Embeddings
from model.transformer import TransformerBlock

tokenizer = BPETokenizer()
tokenizer.load(os.path.join(ROOT, "checkpoints", "tokenizer.json"))

tokens = tokenizer.encode(
    "Привет! NOVA умеет обрабатывать текст."
)

embedding = Embeddings(
    len(tokenizer.vocab),
    embed_size=64
)

vectors = embedding.forward(tokens)

block = TransformerBlock(
    embed_size=64,
    hidden_size=256
)

output = block.forward(vectors)

print("NOVA AI — TRANSFORMER TEST")
print("Входная форма:", vectors.shape)
print("Выходная форма:", output.shape)
print("Первые 5 значений:", output[0][:5])
print("Все значения конечные:", np.isfinite(output).all())
print("TEST COMPLETE")