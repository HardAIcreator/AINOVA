
import sys
import numpy as np

sys.path.insert(0, "/storage/emulated/0/nova_ai/nova2")

from model.language_model import LanguageModel

path = "/storage/emulated/0/nova_ai/nova2/checkpoints/nova_model.npz"

model1 = LanguageModel(
    vocab_size=50,
    embed_size=64,
    hidden_size=256,
    num_layers=2
)

# Изменяем веса для проверки
model1.embeddings.weights += 0.1
model1.blocks[0].attention.Wq += 0.05
model1.blocks[0].feed_forward.W1 += 0.02
model1.output_weights += 0.03

# Сохраняем
model1.save(path)

# Создаём новую модель
model2 = LanguageModel(
    vocab_size=50,
    embed_size=64,
    hidden_size=256,
    num_layers=2
)

# Загружаем веса
model2.load(path)

# Проверяем совпадение
checks = [
    np.array_equal(
        model1.embeddings.weights,
        model2.embeddings.weights
    ),
    np.array_equal(
        model1.blocks[0].attention.Wq,
        model2.blocks[0].attention.Wq
    ),
    np.array_equal(
        model1.blocks[0].feed_forward.W1,
        model2.blocks[0].feed_forward.W1
    ),
    np.array_equal(
        model1.output_weights,
        model2.output_weights
    )
]

print("NOVA AI — CHECKPOINT TEST")
print("Embeddings:", checks[0])
print("Attention:", checks[1])
print("FeedForward:", checks[2])
print("Output:", checks[3])
print("ALL CHECKS PASSED:", all(checks))
print("TEST COMPLETE")
