
from pathlib import Path

path = Path("/storage/emulated/0/nova_ai/nova2/scripts/train.py")

code = r'''
import sys
from pathlib import Path
import numpy as np

ROOT = Path("/storage/emulated/0/nova_ai/nova2")
sys.path.insert(0, str(ROOT))

from model.tokenizer import BPETokenizer
from model.language_model import LanguageModel
from model.training import OutputTrainer
from model.loss import cross_entropy


DATA = ROOT / "data"
CHECKPOINTS = ROOT / "checkpoints"

EPOCHS = 100
LEARNING_RATE = 0.0001
EMBED_SIZE = 64
HIDDEN_SIZE = 256
NUM_LAYERS = 2


def read_text(path):
    if not path.exists():
        raise FileNotFoundError(f"Файл не найден: {path}")

    text = path.read_text(encoding="utf-8").strip()

    if not text:
        raise ValueError(f"Файл пустой: {path}")

    return text


def make_sequences(token_ids):
    if len(token_ids) < 2:
        raise ValueError("Для обучения нужно минимум 2 токена")

    inputs = np.asarray(token_ids[:-1], dtype=np.int64)
    targets = np.asarray(token_ids[1:], dtype=np.int64)

    return inputs, targets


def evaluate(model, inputs, targets):
    logits = model.forward(inputs)
    return cross_entropy(logits, targets)


def main():
    CHECKPOINTS.mkdir(parents=True, exist_ok=True)

    train_text = read_text(DATA / "train.txt")
    validation_text = read_text(DATA / "validation.txt")

    tokenizer = BPETokenizer()
    tokenizer.fit([train_text], vocab_size=500)

    train_ids = tokenizer.encode(train_text)
    validation_ids = tokenizer.encode(validation_text)

    train_x, train_y = make_sequences(train_ids)
    val_x, val_y = make_sequences(validation_ids)

    model = LanguageModel(
        vocab_size=len(tokenizer.vocab),
        embed_size=EMBED_SIZE,
        hidden_size=HIDDEN_SIZE,
        num_layers=NUM_LAYERS
    )

    trainer = OutputTrainer(learning_rate=LEARNING_RATE)

    print("NOVA AI — TRAINING ENGINE")
    print("Vocabulary:", len(tokenizer.vocab))
    print("Training tokens:", len(train_ids))
    print("Validation tokens:", len(validation_ids))
    print("Epochs:", EPOCHS)
    print()

    for epoch in range(EPOCHS):
        train_loss = trainer.train_step(
            train_x, train_y, model
        )

        if not np.isfinite(train_loss):
            raise FloatingPointError("Training Loss is not finite")

        if (epoch + 1) % 10 == 0 or epoch == 0:
            val_loss = evaluate(model, val_x, val_y)

            print(
                f"Epoch {epoch + 1} | "
                f"Train Loss: {train_loss:.6f} | "
                f"Validation Loss: {val_loss:.6f}"
            )

    tokenizer.save(str(CHECKPOINTS / "tokenizer.json"))

    print()
    print("Tokenizer saved.")
    print("Training finished.")
    print("NOTE: Model weight saving will be added next.")
    print("NOVA AI TRAINING COMPLETE")


if __name__ == "__main__":
    main()
'''

path.write_text(code.strip() + "\n", encoding="utf-8")

print("TRAIN SCRIPT REPLACED:", path.exists())
print("SIZE:", path.stat().st_size)
