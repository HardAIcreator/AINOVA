
import os
import inspect
import sys

BASE = "/storage/emulated/0/nova_ai/nova2"
os.chdir(BASE)
sys.path.insert(0, BASE)

print("NOVA AI — INTEGRATION CHECK")
print("=" * 35)

files = [
    "generate_v31.py",
    "model/language_model.py",
    "model/tokenizer.py",
    "checkpoints_v31/best_model.npz",
    "checkpoints_v31/best_tokenizer.json"
]

for file in files:
    print(file, ":", os.path.exists(file))

print("\n--- GENERATOR SOURCE ---")

if os.path.exists("generate_v31.py"):
    with open("generate_v31.py", "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if i >= 180:
                print("... truncated")
                break
            print(line, end="")

print("\n--- MODEL API ---")

try:
    from model.language_model import LanguageModel

    print("LanguageModel:", LanguageModel)
    print("Constructor:", inspect.signature(LanguageModel))

    for name in dir(LanguageModel):
        if not name.startswith("_"):
            obj = getattr(LanguageModel, name)
            if callable(obj):
                try:
                    print(name, inspect.signature(obj))
                except Exception:
                    print(name)

except Exception as e:
    print("MODEL IMPORT ERROR:", repr(e))

print("\n--- TOKENIZER API ---")

try:
    from model.tokenizer import BPETokenizer

    print("BPETokenizer:", BPETokenizer)
    print("Constructor:", inspect.signature(BPETokenizer))

    for name in dir(BPETokenizer):
        if not name.startswith("_"):
            obj = getattr(BPETokenizer, name)
            if callable(obj):
                try:
                    print(name, inspect.signature(obj))
                except Exception:
                    print(name)

except Exception as e:
    print("TOKENIZER ERROR:", repr(e))

print("\nINTEGRATION CHECK COMPLETE")
