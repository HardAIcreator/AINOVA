
from pathlib import Path

path = Path("/storage/emulated/0/nova_ai/nova2/model/language_model.py")

code = r'''
import numpy as np
from model.embeddings import Embeddings
from model.transformer import TransformerBlock


def softmax(x):
    x = x - np.max(x, axis=-1, keepdims=True)
    exp = np.exp(x)
    return exp / np.sum(exp, axis=-1, keepdims=True)


class LanguageModel:
    def __init__(
        self,
        vocab_size,
        embed_size=64,
        hidden_size=256,
        num_layers=2,
        seed=42
    ):
        self.vocab_size = vocab_size
        self.embed_size = embed_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers

        self.embeddings = Embeddings(
            vocab_size, embed_size, seed
        )

        self.blocks = [
            TransformerBlock(
                embed_size, hidden_size, seed + i
            )
            for i in range(num_layers)
        ]

        rng = np.random.default_rng(seed)

        self.output_weights = rng.normal(
            0,
            1 / np.sqrt(embed_size),
            (embed_size, vocab_size)
        )

        self.output_bias = np.zeros(vocab_size)

    def forward_features(self, token_ids):
        x = self.embeddings.forward(token_ids)

        for block in self.blocks:
            x = block.forward(x)

        return x

    def forward(self, token_ids):
        features = self.forward_features(token_ids)

        return (
            features @ self.output_weights
            + self.output_bias
        )

    def predict(self, token_ids):
        logits = self.forward(token_ids)
        return softmax(logits[-1])

    def save(self, path):
        data = {
            "embeddings": self.embeddings.weights,
            "output_weights": self.output_weights,
            "output_bias": self.output_bias
        }

        for i, block in enumerate(self.blocks):
            prefix = f"block_{i}_"

            data[prefix + "Wq"] = block.attention.Wq
            data[prefix + "Wk"] = block.attention.Wk
            data[prefix + "Wv"] = block.attention.Wv
            data[prefix + "Wo"] = block.attention.Wo

            data[prefix + "norm1_gamma"] = block.norm1.gamma
            data[prefix + "norm1_beta"] = block.norm1.beta
            data[prefix + "norm2_gamma"] = block.norm2.gamma
            data[prefix + "norm2_beta"] = block.norm2.beta

            ff = block.feed_forward

            data[prefix + "ff_W1"] = ff.W1
            data[prefix + "ff_b1"] = ff.b1
            data[prefix + "ff_W2"] = ff.W2
            data[prefix + "ff_b2"] = ff.b2

        np.savez_compressed(path, **data)

    def load(self, path):
        with np.load(path) as data:
            expected = {
                "embeddings": self.embeddings.weights.shape,
                "output_weights": self.output_weights.shape,
                "output_bias": self.output_bias.shape
            }

            for name, shape in expected.items():
                if name not in data or data[name].shape != shape:
                    raise ValueError(
                        f"Invalid checkpoint parameter: {name}"
                    )

            self.embeddings.weights = data["embeddings"].copy()
            self.output_weights = data["output_weights"].copy()
            self.output_bias = data["output_bias"].copy()

            for i, block in enumerate(self.blocks):
                prefix = f"block_{i}_"

                parameters = {
                    "Wq": block.attention.Wq,
                    "Wk": block.attention.Wk,
                    "Wv": block.attention.Wv,
                    "Wo": block.attention.Wo,
                    "norm1_gamma": block.norm1.gamma,
                    "norm1_beta": block.norm1.beta,
                    "norm2_gamma": block.norm2.gamma,
                    "norm2_beta": block.norm2.beta,
                    "ff_W1": block.feed_forward.W1,
                    "ff_b1": block.feed_forward.b1,
                    "ff_W2": block.feed_forward.W2,
                    "ff_b2": block.feed_forward.b2
                }

                for name, current in parameters.items():
                    key = prefix + name

                    if key not in data or data[key].shape != current.shape:
                        raise ValueError(
                            f"Invalid checkpoint parameter: {key}"
                        )

                    current[...] = data[key]

'''

path.write_text(code.strip() + "\n", encoding="utf-8")

print("LANGUAGE MODEL UPDATED")
print("File:", path)
print("Size:", path.stat().st_size)
print("SAVE METHOD:", "save" in code)
print("LOAD METHOD:", "load" in code)
