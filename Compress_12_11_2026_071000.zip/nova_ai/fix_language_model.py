path = "/storage/emulated/0/nova_ai/nova2/model/language_model.py"

code = '''import numpy as np
from model.embeddings import Embeddings
from model.transformer import TransformerBlock


def softmax(x):
    x = x - np.max(x, axis=-1, keepdims=True)
    exp = np.exp(x)
    return exp / np.sum(exp, axis=-1, keepdims=True)


class LanguageModel:
    def __init__(
        self,
        vocab_size,
        embed_size=64,
        hidden_size=256,
        num_layers=2,
        seed=42
    ):
        self.vocab_size = vocab_size
        self.embed_size = embed_size

        self.embeddings = Embeddings(
            vocab_size, embed_size, seed
        )

        self.blocks = [
            TransformerBlock(
                embed_size,
                hidden_size,
                seed + i
            )
            for i in range(num_layers)
        ]

        rng = np.random.default_rng(seed)

        self.output_weights = rng.normal(
            0,
            1 / np.sqrt(embed_size),
            (embed_size, vocab_size)
        )

        self.output_bias = np.zeros(vocab_size)

    def forward(self, token_ids):
        x = self.embeddings.forward(token_ids)

        for block in self.blocks:
            x = block.forward(x)

        logits = x @ self.output_weights + self.output_bias

        return logits

    def predict(self, token_ids):
        logits = self.forward(token_ids)
        probabilities = softmax(logits[-1])
        return probabilities

    def save(self, path):
        data = {
            "embeddings": self.embeddings.weights,
            "output_weights": self.output_weights,
            "output_bias": self.output_bias
        }

        for i, block in enumerate(self.blocks):
            data[f"block_{i}_Wq"] = block.attention.Wq
            data[f"block_{i}_Wk"] = block.attention.Wk
            data[f"block_{i}_Wv"] = block.attention.Wv
            data[f"block_{i}_Wo"] = block.attention.Wo
            data[f"block_{i}_W1"] = block.feed_forward.W1
            data[f"block_{i}_b1"] = block.feed_forward.b1
            data[f"block_{i}_W2"] = block.feed_forward.W2
            data[f"block_{i}_b2"] = block.feed_forward.b2

        np.savez(path, **data)
'''

with open(path, "w", encoding="utf-8") as f:
    f.write(code)

print("LANGUAGE MODEL SAVED")
print("Размер:", len(code))