import sys
sys.path.insert(0, "/storage/emulated/0/nova_ai/nova2")

import numpy as np
from model.embeddings import Embeddings

model = Embeddings(vocab_size=50, embed_size=64)

tokens = np.array([1, 2, 1, 5, 2])

output = model.forward(tokens)
grad = np.ones_like(output)

before = model.weights.copy()

model.backward(grad)
model.update(0.001)

print("NOVA AI — EMBEDDINGS BACKWARD TEST")
print("Выход:", output.shape)
print("Градиенты:", model.dweights.shape)
print("Веса изменились:", not np.array_equal(before, model.weights))
print("Градиенты конечные:", np.all(np.isfinite(model.dweights)))
print("TEST COMPLETE")