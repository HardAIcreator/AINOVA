from pathlib import Path

path = Path(
    "/storage/emulated/0/nova_ai/nova2/model/tokenizer.py"
)

code = r'''
import json
import re
from collections import Counter


class BPETokenizer:
    def __init__(self):
        self.vocab = {}
        self.merges = []
        self.unk_token = "<unk>"

    def fit(self, texts, vocab_size=500):
        sequences = []

        for text in texts:
            words = re.findall(r"\w+|[^\w\s]|\s+", text.lower())
            sequences.extend([list(word) for word in words])

        alphabet = set()
        for seq in sequences:
            alphabet.update(seq)

        self.vocab = {self.unk_token: 0}

        for token in sorted(alphabet):
            self.vocab[token] = len(self.vocab)

        self.merges = []

        while len(self.vocab) < vocab_size:
            pairs = Counter()

            for seq in sequences:
                for i in range(len(seq) - 1):
                    pairs[(seq[i], seq[i + 1])] += 1

            if not pairs:
                break

            pair, frequency = pairs.most_common(1)[0]

            if frequency < 2:
                break

            merged = pair[0] + pair[1]
            self.merges.append(pair)

            updated = []

            for seq in sequences:
                result = []
                i = 0

                while i < len(seq):
                    if i + 1 < len(seq) and (
                        seq[i], seq[i + 1]
                    ) == pair:
                        result.append(merged)
                        i += 2
                    else:
                        result.append(seq[i])
                        i += 1

                updated.append(result)

            sequences = updated
            self.vocab[merged] = len(self.vocab)

    def encode(self, text):
        words = re.findall(r"\w+|[^\w\s]|\s+", text.lower())
        result = []
        unk_id = self.vocab[self.unk_token]

        for word in words:
            seq = list(word)

            for pair in self.merges:
                merged = pair[0] + pair[1]
                updated = []
                i = 0

                while i < len(seq):
                    if i + 1 < len(seq) and (
                        seq[i], seq[i + 1]
                    ) == pair:
                        updated.append(merged)
                        i += 2
                    else:
                        updated.append(seq[i])
                        i += 1

                seq = updated

            result.extend(
                self.vocab.get(token, unk_id)
                for token in seq
            )

        return result

    def decode(self, tokens):
        inverse = {
            i: token for token, i in self.vocab.items()
        }

        return "".join(
            inverse.get(token, self.unk_token)
            for token in tokens
        )

    def save(self, path):
        data = {
            "vocab": self.vocab,
            "merges": self.merges,
            "unk_token": self.unk_token
        }

        with open(path, "w", encoding="utf-8") as file:
            json.dump(data, file, ensure_ascii=False, indent=2)

    def load(self, path):
        with open(path, "r", encoding="utf-8") as file:
            data = json.load(file)

        self.vocab = data["vocab"]
        self.merges = [
            tuple(pair) for pair in data["merges"]
        ]
        self.unk_token = data.get("unk_token", "<unk>")
'''

path.write_text(code.strip() + "\n", encoding="utf-8")

print("NOVA AI — TOKENIZER REPLACEMENT")
print("Файл:", path)
print("Размер:", path.stat().st_size, "байт")
print("Заменён:", path.exists())
print("REPLACEMENT COMPLETE")