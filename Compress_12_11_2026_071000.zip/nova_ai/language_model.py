import sys
import os

ROOT = "/storage/emulated/0/nova_ai/nova2"

if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

os.chdir(ROOT)

import numpy as np
from model.tokenizer import BPETokenizer
from model.language_model import LanguageModel

print("NOVA AI — LANGUAGE MODEL TEST")

tokenizer = BPETokenizer()
tokenizer.load(os.path.join(ROOT, "checkpoints/tokenizer.json"))

text = "Привет! NOVA умеет обрабатывать текст."
tokens = np.array(tokenizer.encode(text), dtype=np.int64)

model = LanguageModel(
    vocab_size=len(tokenizer.vocab),
    embed_size=64,
    hidden_size=256,
    num_layers=2
)

features = model.forward_features(tokens)
logits = model.forward(tokens)
probabilities = model.predict(tokens)

print("Features:", features.shape)
print("Logits:", logits.shape)
print("Probabilities:", probabilities.shape)
print("Сумма вероятностей:", probabilities.sum())
print("Все значения конечные:", np.isfinite(logits).all())

print("TEST COMPLETE")