import os
import sys
import numpy as np

ROOT = "/storage/emulated/0/nova_ai"
sys.path.insert(0, ROOT)

from nova.tokenizer import Tokenizer
from nova.nn.rnn import CharRNN

# Загружаем текст
with open(os.path.join(ROOT, "data", "training.txt"),
          "r", encoding="utf-8") as f:
    text = f.read()

# Создаём словарь
tokenizer = Tokenizer()
tokenizer.fit([text])

tokens = tokenizer.encode(text)

# Создаём модель
net = CharRNN(
    vocab_size=len(tokenizer.vocab),
    hidden_size=64
)

# Обучение
sequence_length = 16
epochs = 100
lr = 0.005

print("NOVA AI — RNN TRAINING")
print("Символов:", len(tokens))
print("Словарь:", len(tokenizer.vocab))

for epoch in range(1, epochs + 1):
    total_loss = 0

    indices = np.random.permutation(
        len(tokens) - sequence_length
    )

    for i in indices:
        X = tokens[i:i + sequence_length]
        Y = tokens[i + sequence_length]

        loss = net.train_step(X, Y, lr=lr)
        total_loss += loss

    avg_loss = total_loss / len(indices)

    if epoch == 1 or epoch % 5 == 0:
        print(f"Epoch {epoch}: Loss = {avg_loss:.4f}")

# Сохраняем модель и словарь
checkpoint = os.path.join(ROOT, "checkpoints")
os.makedirs(checkpoint, exist_ok=True)

net.save(os.path.join(checkpoint, "nova_rnn.npz"))
tokenizer.save(os.path.join(checkpoint, "nova_vocab.json"))

print("\nОбучение завершено!")
print("Модель сохранена!")