import os
import sys
import numpy as np

ROOT = "/storage/emulated/0/nova_ai"
sys.path.insert(0, ROOT)

from nova.tokenizer import Tokenizer
from nova.nn.rnn import CharRNN

ck = os.path.join(ROOT, "checkpoints")
tok = Tokenizer()
tok.load(os.path.join(ck, "nova_vocab.json"))
net = CharRNN(vocab_size=len(tok.vocab), hidden_size=64)
net.load(os.path.join(ck, "nova_rnn.npz"))


def generate(prompt, length=200, temperature=0.5, window=16):
    rng = np.random.default_rng()
    tokens = tok.encode(prompt)
    for _ in range(length):
        probs, _ = net.forward(tokens[-window:])
        logits = np.log(probs + 1e-12) / temperature
        p = np.exp(logits - logits.max())
        p /= p.sum()
        tokens.append(int(rng.choice(len(p), p=p)))
    return tok.decode(tokens)


print(generate("Привет! Меня зовут"))