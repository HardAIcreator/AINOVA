
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

import numpy as np
from nova.nn.network import MLP

# Создание обучающих данных XOR
rng = np.random.default_rng(1)
X = rng.uniform(-1, 1, (400, 2))
y = ((X[:, 0] > 0) ^ (X[:, 1] > 0)).astype(int)

# Создание нейросети
net = MLP([2, 16, 16, 2], seed=0)

# Проверка градиентов
net.loss_and_backward(X, y)

W = net.layers[0].W
analytic = net.layers[0].dW[0, 0]

old, eps = W[0, 0], 1e-5

W[0, 0] = old + eps
lp = net.compute_loss(X, y)

W[0, 0] = old - eps
lm = net.compute_loss(X, y)

W[0, 0] = old
numeric = (lp - lm) / (2 * eps)

print("Градиенты:")
print("Backprop:", analytic)
print("Численный:", numeric)

# Обучение
w_before = net.layers[0].W.copy()

for epoch in range(1, 1001):
    loss = net.loss_and_backward(X, y)
    net.step(0.5)

    if epoch == 1 or epoch % 200 == 0:
        print(f"Epoch {epoch}: Loss = {loss:.4f}")

# Проверка точности
acc = (net.forward(X).argmax(axis=1) == y).mean()

change = abs(net.layers[0].W - w_before).sum()

print("\nРЕЗУЛЬТАТЫ NOVA AI")
print("Точность:", round(float(acc), 3))
print("Изменение весов:", round(float(change), 3))

# Сохранение
path = os.path.join(ROOT, "checkpoints", "stage2.npz")
os.makedirs(os.path.dirname(path), exist_ok=True)

net.save(path)

# Проверка загрузки
net2 = MLP([2, 16, 16, 2], seed=99)
net2.load(path)

same = np.allclose(net.forward(X), net2.forward(X))

print("Загрузка весов совпадает:", same)
print("Модель сохранена:", path)
