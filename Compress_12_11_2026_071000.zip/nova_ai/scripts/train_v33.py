import sys
from pathlib import Path
import numpy as np

print("1. NUMPY OK", flush=True)

ROOT = Path("/storage/emulated/0/nova_ai/nova2")
sys.path.insert(0, str(ROOT))

print("2. PATH OK", flush=True)

from model.tokenizer import BPETokenizer
print("3. TOKENIZER OK", flush=True)

from model.language_model import LanguageModel
print("4. LANGUAGE MODEL OK", flush=True)

from model.training import OutputTrainer
print("5. TRAINER OK", flush=True)

from model.loss import cross_entropy
print("6. LOSS OK", flush=True)

from model.tokenizer import BPETokenizer
from model.language_model import LanguageModel
from model.training import OutputTrainer
from model.loss import cross_entropy

DATA = ROOT / "data_v33"
OUTPUT = ROOT / "checkpoints_v33"

EPOCHS = 30
LEARNING_RATE = 0.0001
EMBED_SIZE = 64
HIDDEN_SIZE = 256
NUM_LAYERS = 2
BLOCK_SIZE = 128
VOCAB_SIZE = 500
SAVE_EVERY = 5

rng = np.random.default_rng(42)


def read_text(path):
    if not path.exists():
        raise FileNotFoundError(str(path))

    text = path.read_text(encoding="utf-8").strip()

    if not text:
        raise ValueError("Empty dataset: " + str(path))

    return text


def make_chunks(ids):
    x = np.asarray(ids[:-1], dtype=np.int64)
    y = np.asarray(ids[1:], dtype=np.int64)

    chunks = []

    for start in range(0, len(x), BLOCK_SIZE):
        end = min(start + BLOCK_SIZE, len(x))

        if end > start:
            chunks.append((x[start:end], y[start:end]))

    return chunks


def evaluate(model, chunks):
    losses = []

    for x, y in chunks:
        loss = cross_entropy(model.forward(x), y)

        if not np.isfinite(loss):
            raise FloatingPointError("Invalid validation loss")

        losses.append(loss)

    return float(np.mean(losses))


def save_state(model, tokenizer, name):
    OUTPUT.mkdir(parents=True, exist_ok=True)

    model.save(str(OUTPUT / f"{name}_model.npz"))
    tokenizer.save(str(OUTPUT / f"{name}_tokenizer.json"))


def main():
    print("MAIN: START", flush=True)
    OUTPUT.mkdir(parents=True, exist_ok=True)

    train_text = read_text(DATA / "train.txt")
    print("MAIN: TRAIN READ", len(train_text), flush=True)

    val_text = read_text(DATA / "validation.txt")
    print("MAIN: VALIDATION READ", len(val_text), flush=True)

    # Словарь строится только по обучающим данным.
    print("MAIN: TOKENIZER START",flush=True)
    tokenizer = BPETokenizer()
    tokenizer.fit([train_text],vocab_size=VOCAB_SIZE)
   
    print("MAIN: TOKENIZER DONE", flush=True)
    print("VOCAB:", len(tokenizer.vocab), flush=True)

    train_ids = tokenizer.encode(train_text)
    val_ids = tokenizer.encode(val_text)

    train_chunks = make_chunks(train_ids)
    val_chunks = make_chunks(val_ids)

    if not train_chunks or not val_chunks:
        raise ValueError("Not enough tokens")

    model = LanguageModel(
        vocab_size=len(tokenizer.vocab),
        embed_size=EMBED_SIZE,
        hidden_size=HIDDEN_SIZE,
        num_layers=NUM_LAYERS
    )

    trainer = OutputTrainer(
        learning_rate=LEARNING_RATE
    )

    best_loss = float("inf")

    unknown = sum(token_id == 0 for token_id in val_ids)
    unknown_percent = 100 * unknown / max(1, len(val_ids))

    print("NOVA AI 3.3 — TRAINING ENGINE")
    print("Dataset: Russian")
    print("Vocabulary:", len(tokenizer.vocab))
    print("Train tokens:", len(train_ids))
    print("Validation tokens:", len(val_ids))
    print("Unknown validation tokens:", f"{unknown_percent:.2f}%")
    print("Training blocks:", len(train_chunks))
    print("Epochs:", EPOCHS)
    print("Output:", OUTPUT)
    print()

    for epoch in range(EPOCHS):
        epoch_losses = []

        order = rng.permutation(len(train_chunks))

        for index in order:
            x, y = train_chunks[int(index)]

            loss = trainer.train_step(x, y, model)

            if not np.isfinite(loss):
                raise FloatingPointError("Invalid training loss")

            epoch_losses.append(loss)

        train_loss = float(np.mean(epoch_losses))
        val_loss = evaluate(model, val_chunks)

        print(
            f"Epoch {epoch + 1} | "
            f"Train: {train_loss:.6f} | "
            f"Validation: {val_loss:.6f}"
        )

        if val_loss < best_loss:
            best_loss = val_loss
            save_state(model, tokenizer, "best")
            print("  BEST MODEL SAVED")

        if (epoch + 1) % SAVE_EVERY == 0:
            save_state(model, tokenizer, "latest")
            print("  CHECKPOINT SAVED")

    # Сохраняем последнюю версию даже при завершении
    # между контрольными точками.
    save_state(model, tokenizer, "latest")

    print()
    print("BEST VALIDATION LOSS:", best_loss)
    print("OUTPUT:", OUTPUT)
    print("BEFORE MAIN", flush=True)

print("7. BEFORE MAIN", flush=True)

try:
    main()
    print("8. MAIN FINISHED", flush=True)
except Exception:
    import traceback
    traceback.print_exc()