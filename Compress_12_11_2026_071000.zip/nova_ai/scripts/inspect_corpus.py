
from pathlib import Path

ROOT = Path("/storage/emulated/0/nova_ai/nova2/data_v2")

print("NOVA AI — CORPUS STRUCTURE")

for path in sorted(ROOT.rglob("*")):
    if path.is_file():
        print(
            path.relative_to(ROOT),
            "|", path.stat().st_size, "bytes"
        )

print("\n=== SOURCES.TSV ===")

sources = ROOT / "sources.tsv"

if sources.exists():
    print(sources.read_text(encoding="utf-8")[:12000])
else:
    print("sources.tsv NOT FOUND")

print("\nINSPECTION COMPLETE")
