"""Read-only: show what is inside data_v2/documents.jsonl."""
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
path = ROOT / "data_v2" / "documents.jsonl"

if not path.exists():
    print("documents.jsonl not found:", path)
    raise SystemExit

docs = []
broken = 0
with path.open("r", encoding="utf-8") as file:
    for line in file:
        if not line.strip():
            continue
        try:
            docs.append(json.loads(line))
        except json.JSONDecodeError:
            broken += 1

print("file:", path)
print("size:", path.stat().st_size, "bytes")
print("documents:", len(docs), "| broken lines:", broken)
print("per language:", dict(Counter(d["lang"] for d in docs)))

times = sorted(d.get("retrieved_utc", "") for d in docs)
if times:
    print("retrieved from", times[0], "to", times[-1])
    print("distinct minutes:", sorted({t[:16] for t in times}))

print()
for d in docs:
    print(
        f"{d['lang']} | {d['title'][:40]:<40} | "
        f"{d.get('chars', len(d['text'])):>5} chars | "
        f"{d.get('retrieved_utc', '')}"
    )