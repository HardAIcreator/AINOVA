import os
import sys
import numpy as np

ROOT = "/storage/emulated/0/nova_ai"
sys.path.insert(0, ROOT)

from nova.tokenizer import Tokenizer

# Читаем текст
path = os.path.join(ROOT, "data", "training.txt")

with open(path, "r", encoding="utf-8") as f:
    text = f.read()

# Загружаем токенизатор
tokenizer = Tokenizer()
tokenizer.fit([text])

# Превращаем текст в числа
tokens = tokenizer.encode(text)

# Создаём пары для обучения
sequence_length = 16

X = []
Y = []

for i in range(len(tokens) - sequence_length):
    X.append(tokens[i:i + sequence_length])
    Y.append(tokens[i + sequence_length])

X = np.array(X)
Y = np.array(Y)

print("NOVA AI — SEQUENCES")
print("Всего токенов:", len(tokens))
print("Размер словаря:", len(tokenizer.vocab))
print("Количество примеров:", len(X))
print("Форма X:", X.shape)
print("Форма Y:", Y.shape)

print("\nПервый пример:")
print("Вход:", X[0])
print("Цель:", Y[0])