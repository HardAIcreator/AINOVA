import sys
sys.path.insert(0, "/storage/emulated/0/nova_ai/nova2")

import numpy as np
from model.language_model import LanguageModel
from model.training import OutputTrainer

model = LanguageModel(
    vocab_size=50,
    embed_size=64,
    hidden_size=256,
    num_layers=2
)

trainer = OutputTrainer(learning_rate=0.001)

tokens = np.array([1, 2, 3, 4, 5, 6, 7, 8])
targets = np.array([2, 3, 4, 5, 6, 7, 8, 9])

print("NOVA AI — FULL TRAINING")
print("Epochs: 100")

losses = []

for epoch in range(100):
    loss = trainer.train_step(tokens, targets, model)
    losses.append(loss)

    if epoch == 0 or (epoch + 1) % 10 == 0:
        print(
            f"Epoch {epoch + 1} | Loss: {loss:.6f}"
        )

print("\nINITIAL LOSS:", losses[0])
print("FINAL LOSS:", losses[-1])
print("LOSS DECREASED:", losses[-1] < losses[0])
print("ALL FINITE:", np.all(np.isfinite(losses)))
print("TRAINING COMPLETE")