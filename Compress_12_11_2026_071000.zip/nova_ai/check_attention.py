import os

folder = "/storage/emulated/0/nova_ai/nova2/model"

print("Файлы в папке model:")
for name in os.listdir(folder):
    print(name)

path = os.path.join(folder, "attention.py")

print("\nФайл существует:", os.path.exists(path))

if os.path.exists(path):
    with open(path, "r", encoding="utf-8") as f:
        print("\nСодержимое:")
        print(f.read())