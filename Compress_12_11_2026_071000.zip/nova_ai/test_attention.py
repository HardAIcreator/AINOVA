import sys
import os

ROOT = "/storage/emulated/0/nova_ai/nova2"
sys.path.insert(0, ROOT)

from model.tokenizer import BPETokenizer
from model.embeddings import Embeddings
from model.attention import SelfAttention

tokenizer = BPETokenizer()
tokenizer.load(
    os.path.join(ROOT, "checkpoints", "tokenizer.json")
)

text = "Привет! NOVA умеет обрабатывать текст."
tokens = tokenizer.encode(text)

embedding = Embeddings(
    vocab_size=len(tokenizer.vocab),
    embed_size=64
)

vectors = embedding.forward(tokens)

attention = SelfAttention(embed_size=64)
output = attention.forward(vectors)

print("NOVA AI — ATTENTION TEST")
print("Количество токенов:", len(tokens))
print("Входная форма:", vectors.shape)
print("Выходная форма:", output.shape)
print("Первые 5 значений:", output[0][:5])
print("Все значения конечные:", __import__("numpy").isfinite(output).all())
print("TEST COMPLETE")