path = "/storage/emulated/0/nova_ai/nova2/model/transformer.py"

code = '''import numpy as np
from model.attention import SelfAttention


class LayerNorm:
    def __init__(self, embed_size, eps=1e-5):
        self.gamma = np.ones(embed_size)
        self.beta = np.zeros(embed_size)
        self.eps = eps

    def forward(self, x):
        mean = np.mean(x, axis=-1, keepdims=True)
        variance = np.var(x, axis=-1, keepdims=True)
        normalized = (x - mean) / np.sqrt(variance + self.eps)
        return self.gamma * normalized + self.beta


class FeedForward:
    def __init__(self, embed_size=64, hidden_size=256, seed=42):
        rng = np.random.default_rng(seed)

        self.W1 = rng.normal(
            0, 1 / np.sqrt(embed_size),
            (embed_size, hidden_size)
        )
        self.b1 = np.zeros(hidden_size)

        self.W2 = rng.normal(
            0, 1 / np.sqrt(hidden_size),
            (hidden_size, embed_size)
        )
        self.b2 = np.zeros(embed_size)

    def forward(self, x):
        hidden = x @ self.W1 + self.b1
        hidden = np.maximum(0, hidden)
        return hidden @ self.W2 + self.b2


class TransformerBlock:
    def __init__(self, embed_size=64, hidden_size=256, seed=42):
        self.attention = SelfAttention(embed_size, seed)
        self.norm1 = LayerNorm(embed_size)
        self.norm2 = LayerNorm(embed_size)
        self.feed_forward = FeedForward(
            embed_size, hidden_size, seed + 1
        )

    def forward(self, x):
        attention_output = self.attention.forward(x)
        x = self.norm1(x + attention_output)

        ff_output = self.feed_forward.forward(x)
        x = self.norm2(x + ff_output)

        return x
'''

with open(path, "w", encoding="utf-8") as f:
    f.write(code)

with open(path, "r", encoding="utf-8") as f:
    saved = f.read()

print("Размер:", len(saved))
print("TransformerBlock найден:", "class TransformerBlock" in saved)
print("TRANSFORMER SAVED")