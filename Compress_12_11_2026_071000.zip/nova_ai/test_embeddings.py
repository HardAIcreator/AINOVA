
import sys
import os
import numpy as np

ROOT = "/storage/emulated/0/nova_ai/nova2"
sys.path.insert(0, ROOT)

from model.tokenizer import BPETokenizer
from model.embeddings import Embeddings

tokenizer = BPETokenizer()
tokenizer.load(
    os.path.join(ROOT, "checkpoints", "tokenizer.json")
)

text = "Привет! NOVA умеет обрабатывать текст."
tokens = tokenizer.encode(text)

embedding = Embeddings(
    vocab_size=len(tokenizer.vocab),
    embed_size=64
)

vectors = embedding.forward(tokens)

print("NOVA AI — EMBEDDINGS TEST")
print("Токены:", tokens)
print("Размер словаря:", len(tokenizer.vocab))
print("Размер векторов:", vectors.shape)
print("Первые 5 значений:", vectors[0][:5])
print("TEST COMPLETE")
