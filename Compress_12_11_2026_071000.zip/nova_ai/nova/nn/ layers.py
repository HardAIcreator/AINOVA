import numpy as np


class Linear:
    def __init__(self, n_in, n_out, rng):
        self.W = rng.normal(
            0,
            np.sqrt(2.0 / n_in),
            (n_in, n_out)
        )
        self.b = np.zeros(n_out)
        self.x = None
        self.dW = None
        self.db = None

    def forward(self, x):
        self.x = x
        return x @ self.W + self.b

    def backward(self, grad):
        self.dW = self.x.T @ grad
        self.db = grad.sum(axis=0)
        return grad @ self.W.T


class Tanh:
    def __init__(self):
        self.out = None

    def forward(self, x):
        self.out = np.tanh(x)
        return self.out

    def backward(self, grad):
        return grad * (1.0 - self.out ** 2)