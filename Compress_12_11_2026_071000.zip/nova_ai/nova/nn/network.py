import numpy as np
from .layers import Linear, Tanh


def softmax(z):
    z = z - z.max(axis=1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=1, keepdims=True)


class MLP:
    def __init__(self, sizes, seed=0):
        rng = np.random.default_rng(seed)
        self.layers = []

        for i in range(len(sizes) - 1):
            self.layers.append(
                Linear(sizes[i], sizes[i + 1], rng)
            )

            if i < len(sizes) - 2:
                self.layers.append(Tanh())

    def forward(self, x):
        for layer in self.layers:
            x = layer.forward(x)
        return x

    def compute_loss(self, x, y):
        p = softmax(self.forward(x))
        n = x.shape[0]
        return -np.log(
            p[np.arange(n), y] + 1e-12
        ).mean()

    def loss_and_backward(self, x, y):
        p = softmax(self.forward(x))
        n = x.shape[0]

        loss = -np.log(
            p[np.arange(n), y] + 1e-12
        ).mean()

        grad = p.copy()
        grad[np.arange(n), y] -= 1.0
        grad /= n

        for layer in reversed(self.layers):
            grad = layer.backward(grad)

        return loss

    def step(self, lr):
        for layer in self.layers:
            if isinstance(layer, Linear):
                layer.W -= lr * layer.dW
                layer.b -= lr * layer.db

    def save(self, path):
        data = {}

        for i, layer in enumerate(self.layers):
            if isinstance(layer, Linear):
                data[f"W{i}"] = layer.W
                data[f"b{i}"] = layer.b

        np.savez(path, **data)

    def load(self, path):
        data = np.load(path)

        for i, layer in enumerate(self.layers):
            if isinstance(layer, Linear):
                layer.W = data[f"W{i}"].copy()
                layer.b = data[f"b{i}"].copy()

        data.close()