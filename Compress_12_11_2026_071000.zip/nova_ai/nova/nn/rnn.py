import numpy as np


def softmax(x):
    x = x - np.max(x)
    e = np.exp(x)
    return e / np.sum(e)


class CharRNN:
    def __init__(self, vocab_size, hidden_size=64, seed=42):
        rng = np.random.default_rng(seed)

        self.vocab_size = vocab_size
        self.hidden_size = hidden_size

        self.U = rng.normal(
            0, 0.01, (vocab_size, hidden_size)
        )

        self.W = rng.normal(
            0, 0.01, (hidden_size, hidden_size)
        )

        self.V = rng.normal(
            0, 0.01, (hidden_size, vocab_size)
        )

        self.bh = np.zeros(hidden_size)
        self.by = np.zeros(vocab_size)

    def forward(self, inputs):
        h = np.zeros(self.hidden_size)
        states = []

        for token in inputs:
            h_prev = h.copy()

            h = np.tanh(
                self.U[token] + h_prev @ self.W + self.bh
            )

            states.append((h.copy(), h_prev, token))

        logits = h @ self.V + self.by
        probs = softmax(logits)

        return probs, states

    def train_step(self, inputs, target, lr=0.05):
        probs, states = self.forward(inputs)

        loss = -np.log(probs[target] + 1e-12)

        dU = np.zeros_like(self.U)
        dW = np.zeros_like(self.W)
        dV = np.zeros_like(self.V)

        dbh = np.zeros_like(self.bh)
        dby = np.zeros_like(self.by)

        dy = probs.copy()
        dy[target] -= 1.0

        h = states[-1][0]

        dV = np.outer(h, dy)
        dby = dy.copy()

        dh = self.V @ dy

        for h, h_prev, token in reversed(states):
            dh_raw = dh * (1.0 - h ** 2)

            dU[token] += dh_raw
            dW += np.outer(h_prev, dh_raw)
            dbh += dh_raw

            dh = self.W @ dh_raw

        for grad in (dU, dW, dV, dbh, dby):
            np.clip(grad, -5, 5, out=grad)

        self.U -= lr * dU
        self.W -= lr * dW
        self.V -= lr * dV
        self.bh -= lr * dbh
        self.by -= lr * dby

        return float(loss)

    def save(self, path):
        np.savez(
            path,
            U=self.U,
            W=self.W,
            V=self.V,
            bh=self.bh,
            by=self.by
        )

    def load(self, path):
        data = np.load(path)

        self.U = data["U"].copy()
        self.W = data["W"].copy()
        self.V = data["V"].copy()
        self.bh = data["bh"].copy()
        self.by = data["by"].copy()

        data.close()