import json


class Tokenizer:
    def __init__(self):
        self.special_tokens = [
            "<PAD>",
            "<UNK>",
            "<BOS>",
            "<EOS>"
        ]

        self.vocab = {}
        self.inverse_vocab = {}

    def fit(self, texts):
        chars = set()

        for text in texts:
            chars.update(text)

        all_tokens = self.special_tokens + sorted(chars)

        self.vocab = {
            token: i
            for i, token in enumerate(all_tokens)
        }

        self.inverse_vocab = {
            i: token
            for token, i in self.vocab.items()
        }

    def encode(self, text):
        return [
            self.vocab.get(char, self.vocab["<UNK>"])
            for char in text
        ]

    def decode(self, tokens):
        result = ""

        for token in tokens:
            char = self.inverse_vocab.get(token, "<UNK>")

            if char not in self.special_tokens:
                result += char

        return result

    def save(self, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.vocab, f, ensure_ascii=False, indent=2)

    def load(self, path):
        with open(path, "r", encoding="utf-8") as f:
            self.vocab = json.load(f)

        self.inverse_vocab = {
            int(i): token
            for token, i in self.vocab.items()
        }