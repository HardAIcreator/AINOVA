import numpy as np


class Embeddings:
    def __init__(self, vocab_size, embed_size=64, seed=42):
        rng = np.random.default_rng(seed)
        self.vocab_size = vocab_size
        self.embed_size = embed_size
        self.weights = rng.normal(0, 0.02, (vocab_size, embed_size))

    def forward(self, token_ids):
        token_ids = np.asarray(token_ids, dtype=np.int64)

        if np.any(token_ids < 0) or np.any(token_ids >= self.vocab_size):
            raise ValueError("Token ID is outside vocabulary")

        self.token_ids = token_ids
        return self.weights[token_ids]

    def backward(self, gradients):
        gradients = np.asarray(gradients, dtype=np.float64)

        if gradients.shape != (len(self.token_ids), self.embed_size):
            raise ValueError("Gradient shape mismatch")

        self.dweights = np.zeros_like(self.weights)
        np.add.at(self.dweights, self.token_ids, gradients)

    def update(self, learning_rate=0.001):
        self.weights -= learning_rate * self.dweights

    def save(self, path):
        np.save(path, self.weights)

    def load(self, path):
        self.weights = np.load(path)

        if self.weights.shape != (self.vocab_size, self.embed_size):
            raise ValueError("Embedding shape mismatch")
