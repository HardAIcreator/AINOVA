
import numpy as np


class TrainerV34:
    def __init__(self, learning_rate=0.0001):
        self.learning_rate = learning_rate

    def train_step(self, token_ids, targets, model):
        token_ids = np.asarray(token_ids, dtype=np.int64)
        targets = np.asarray(targets, dtype=np.int64)

        if token_ids.ndim != 1 or targets.ndim != 1:
            raise ValueError("Inputs must be 1D")

        if len(token_ids) != len(targets):
            raise ValueError("Targets shape mismatch")

        if len(token_ids) == 0:
            raise ValueError("Empty training sequence")

        if np.any(targets < 0) or np.any(targets >= model.vocab_size):
            raise ValueError("Target outside vocabulary")

        # 1. Forward
        features = model.forward_features(token_ids)

        logits = (
            features @ model.output_weights
            + model.output_bias
        )

        logits -= np.max(logits, axis=1, keepdims=True)

        exp = np.exp(logits)
        probabilities = exp / np.sum(
            exp, axis=1, keepdims=True
        )

        # 2. Loss
        loss = -np.mean(
            np.log(
                probabilities[
                    np.arange(len(targets)), targets
                ] + 1e-12
            )
        )

        # 3. Output gradients
        grad_logits = probabilities.copy()

        grad_logits[
            np.arange(len(targets)), targets
        ] -= 1

        grad_logits /= len(targets)

        grad_weights = features.T @ grad_logits
        grad_bias = np.sum(grad_logits, axis=0)

        # 4. Backward
        grad_features = (
            grad_logits @ model.output_weights.T
        )

        for block in reversed(model.blocks):
            grad_features = block.backward(grad_features)

        model.backward_embeddings(grad_features)

        # 5. Update Transformer
        for block in model.blocks:
            block.update(self.learning_rate)

        # 6. Update token embeddings
        model.embeddings.update(self.learning_rate)

        # 7. Update positional embeddings
        model.update_positions(self.learning_rate)

        # 8. Update output layer
        model.output_weights -= (
            self.learning_rate * grad_weights
        )

        model.output_bias -= (
            self.learning_rate * grad_bias
        )

        return float(loss)
