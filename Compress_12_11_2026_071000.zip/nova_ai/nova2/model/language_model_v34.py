
import sys
from pathlib import Path
import numpy as np

ROOT = Path("/storage/emulated/0/nova_ai/nova2")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from model.embeddings import Embeddings
from model.transformer import TransformerBlock
from model.language_model import softmax


class LanguageModelV34:
    def __init__(
        self,
        vocab_size,
        embed_size=64,
        hidden_size=256,
        num_layers=2,
        max_seq_len=128,
        seed=42
    ):
        self.vocab_size = vocab_size
        self.embed_size = embed_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.max_seq_len = max_seq_len

        self.embeddings = Embeddings(
            vocab_size, embed_size, seed
        )

        rng = np.random.default_rng(seed + 100)

        self.position_embeddings = rng.normal(
            0, 0.02, (max_seq_len, embed_size)
        )

        self.blocks = [
            TransformerBlock(
                embed_size,
                hidden_size,
                seed + i
            )
            for i in range(num_layers)
        ]

        self.output_weights = rng.normal(
            0,
            1 / np.sqrt(embed_size),
            (embed_size, vocab_size)
        )

        self.output_bias = np.zeros(vocab_size)

        self.position_gradients = None
        self.sequence_length = 0

    def forward_features(self, token_ids):
        token_ids = np.asarray(
            token_ids, dtype=np.int64
        )

        if token_ids.ndim != 1:
            raise ValueError("Token IDs must be 1D")

        if len(token_ids) == 0:
            raise ValueError("Empty sequence")

        if len(token_ids) > self.max_seq_len:
            raise ValueError("Sequence exceeds max_seq_len")

        self.sequence_length = len(token_ids)

        token_features = self.embeddings.forward(token_ids)

        positions = self.position_embeddings[
            :len(token_ids)
        ]

        x = token_features + positions

        for block in self.blocks:
            x = block.forward(x)

        return x

    def forward(self, token_ids):
        features = self.forward_features(token_ids)

        return (
            features @ self.output_weights
            + self.output_bias
        )

    def predict(self, token_ids):
        logits = self.forward(token_ids)
        return softmax(logits[-1])

    def backward_embeddings(self, gradients):
        gradients = np.asarray(
            gradients, dtype=np.float64
        )

        expected = (
            self.sequence_length,
            self.embed_size
        )

        if gradients.shape != expected:
            raise ValueError("Gradient shape mismatch")

        self.embeddings.backward(gradients)

        self.position_gradients = np.zeros_like(
            self.position_embeddings
        )

        self.position_gradients[
            :self.sequence_length
        ] = gradients

    def update_positions(self, learning_rate):
        if self.position_gradients is None:
            raise RuntimeError("No position gradients")

        self.position_embeddings -= (
            learning_rate * self.position_gradients
        )

    def save(self, path):
        data = {
            "embeddings": self.embeddings.weights,
            "position_embeddings": self.position_embeddings,
            "output_weights": self.output_weights,
            "output_bias": self.output_bias
        }

        for i, block in enumerate(self.blocks):
            prefix = f"block_{i}_"

            data[prefix + "Wq"] = block.attention.Wq
            data[prefix + "Wk"] = block.attention.Wk
            data[prefix + "Wv"] = block.attention.Wv
            data[prefix + "Wo"] = block.attention.Wo

            data[prefix + "norm1_gamma"] = block.norm1.gamma
            data[prefix + "norm1_beta"] = block.norm1.beta
            data[prefix + "norm2_gamma"] = block.norm2.gamma
            data[prefix + "norm2_beta"] = block.norm2.beta

            ff = block.feed_forward

            data[prefix + "ff_W1"] = ff.W1
            data[prefix + "ff_b1"] = ff.b1
            data[prefix + "ff_W2"] = ff.W2
            data[prefix + "ff_b2"] = ff.b2

        np.savez_compressed(path, **data)

    def load(self, path):
        with np.load(path) as data:
            expected = {
                "embeddings": self.embeddings.weights.shape,
                "position_embeddings": self.position_embeddings.shape,
                "output_weights": self.output_weights.shape,
                "output_bias": self.output_bias.shape
            }

            for name, shape in expected.items():
                if name not in data:
                    raise ValueError(
                        f"Missing checkpoint parameter: {name}"
                    )

                if data[name].shape != shape:
                    raise ValueError(
                        f"Invalid checkpoint shape: {name}"
                    )

            self.embeddings.weights = data[
                "embeddings"
            ].copy()

            self.position_embeddings = data[
                "position_embeddings"
            ].copy()

            self.output_weights = data[
                "output_weights"
            ].copy()

            self.output_bias = data[
                "output_bias"
            ].copy()

            for i, block in enumerate(self.blocks):
                prefix = f"block_{i}_"

                parameters = {
                    "Wq": block.attention.Wq,
                    "Wk": block.attention.Wk,
                    "Wv": block.attention.Wv,
                    "Wo": block.attention.Wo,
                    "norm1_gamma": block.norm1.gamma,
                    "norm1_beta": block.norm1.beta,
                    "norm2_gamma": block.norm2.gamma,
                    "norm2_beta": block.norm2.beta,
                    "ff_W1": block.feed_forward.W1,
                    "ff_b1": block.feed_forward.b1,
                    "ff_W2": block.feed_forward.W2,
                    "ff_b2": block.feed_forward.b2
                }

                for name, current in parameters.items():
                    key = prefix + name

                    if key not in data:
                        raise ValueError(
                            f"Missing checkpoint parameter: {key}"
                        )

                    if data[key].shape != current.shape:
                        raise ValueError(
                            f"Invalid checkpoint parameter: {key}"
                        )

                    current[...] = data[key]
