
import numpy as np


class SelfAttention:
    def __init__(self, embed_size=64, seed=42):
        rng = np.random.default_rng(seed)
        self.embed_size = embed_size
        scale = 1 / np.sqrt(embed_size)

        self.Wq = rng.normal(0, scale, (embed_size, embed_size))
        self.Wk = rng.normal(0, scale, (embed_size, embed_size))
        self.Wv = rng.normal(0, scale, (embed_size, embed_size))
        self.Wo = rng.normal(0, scale, (embed_size, embed_size))

    def forward(self, x):
        x = np.asarray(x, dtype=np.float64)

        if x.ndim != 2 or x.shape[1] != self.embed_size:
            raise ValueError("Input shape mismatch")

        self.x = x
        self.Q = x @ self.Wq
        self.K = x @ self.Wk
        self.V = x @ self.Wv
        self.scale = np.sqrt(self.embed_size)

        scores = self.Q @ self.K.T / self.scale
        self.mask = np.triu(
            np.ones(scores.shape, dtype=bool), k=1
        )

        scores = np.where(self.mask, -1e9, scores)
        scores -= np.max(scores, axis=1, keepdims=True)

        self.weights = np.exp(scores)
        self.weights /= np.sum(self.weights, axis=1, keepdims=True)

        self.context = self.weights @ self.V
        return self.context @ self.Wo

    def backward(self, grad):
        grad = np.asarray(grad, dtype=np.float32)

        if grad.shape != self.x.shape:
            raise ValueError("Gradient shape mismatch")

        self.dWo = self.context.T @ grad
        grad_context = grad @ self.Wo.T

        grad_weights = grad_context @ self.V.T
        grad_V = self.weights.T @ grad_context

        grad_scores = self.weights * (
            grad_weights -
            np.sum(grad_weights * self.weights, axis=1, keepdims=True)
        )

        grad_scores = np.where(self.mask, 0.0, grad_scores)

        grad_Q = grad_scores @ self.K / self.scale
        grad_K = grad_scores.T @ self.Q / self.scale

        self.dWq = self.x.T @ grad_Q
        self.dWk = self.x.T @ grad_K
        self.dWv = self.x.T @ grad_V

        return (
            grad_Q @ self.Wq.T
            + grad_K @ self.Wk.T
            + grad_V @ self.Wv.T
        )

    def update(self, learning_rate=0.001):
        self.Wq -= learning_rate * self.dWq
        self.Wk -= learning_rate * self.dWk
        self.Wv -= learning_rate * self.dWv
        self.Wo -= learning_rate * self.dWo
