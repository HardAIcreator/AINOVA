import sys

sys.path.insert(
    0,
    "/storage/emulated/0/nova_ai/nova2"
)

import numpy as np
from model.attention import SelfAttention


class LayerNorm:
    def __init__(self, embed_size, eps=1e-5):
        self.gamma = np.ones(embed_size)
        self.beta = np.zeros(embed_size)
        self.eps = eps

    def forward(self, x):
        self.x = x
        self.mean = np.mean(x, axis=-1, keepdims=True)
        self.var = np.var(x, axis=-1, keepdims=True)
        self.inv_std = 1 / np.sqrt(self.var + self.eps)
        self.x_norm = (x - self.mean) * self.inv_std

        return self.gamma * self.x_norm + self.beta

    def backward(self, grad):
        self.dgamma = np.sum(grad * self.x_norm, axis=0)
        self.dbeta = np.sum(grad, axis=0)

        dx_norm = grad * self.gamma
        size = self.x.shape[-1]

        return (self.inv_std / size) * (
            size * dx_norm
            - np.sum(dx_norm, axis=-1, keepdims=True)
            - self.x_norm * np.sum(
                dx_norm * self.x_norm,
                axis=-1,
                keepdims=True
            )
        )


class FeedForward:
    def __init__(self, embed_size=64, hidden_size=256, seed=42):
        rng = np.random.default_rng(seed)

        self.W1 = rng.normal(
            0, 1 / np.sqrt(embed_size),
            (embed_size, hidden_size)
        )
        self.b1 = np.zeros(hidden_size)

        self.W2 = rng.normal(
            0, 1 / np.sqrt(hidden_size),
            (hidden_size, embed_size)
        )
        self.b2 = np.zeros(embed_size)

    def forward(self, x):
        self.x = x
        self.z1 = x @ self.W1 + self.b1
        self.hidden = np.maximum(0, self.z1)

        return self.hidden @ self.W2 + self.b2

    def backward(self, grad):
        self.dW2 = self.hidden.T @ grad
        self.db2 = np.sum(grad, axis=0)

        grad_hidden = grad @ self.W2.T
        grad_z1 = grad_hidden * (self.z1 > 0)

        self.dW1 = self.x.T @ grad_z1
        self.db1 = np.sum(grad_z1, axis=0)

        return grad_z1 @ self.W1.T

    def update(self, learning_rate=0.001):
        self.W1 -= learning_rate * self.dW1
        self.b1 -= learning_rate * self.db1
        self.W2 -= learning_rate * self.dW2
        self.b2 -= learning_rate * self.db2


class TransformerBlock:
    def __init__(self, embed_size=64, hidden_size=256, seed=42):
        self.attention = SelfAttention(embed_size, seed)

        self.norm1 = LayerNorm(embed_size)
        self.norm2 = LayerNorm(embed_size)

        self.feed_forward = FeedForward(
            embed_size,
            hidden_size,
            seed + 1
        )

    def forward(self, x):
        attention_output = self.attention.forward(x)
        x = self.norm1.forward(x + attention_output)

        ff_output = self.feed_forward.forward(x)
        x = self.norm2.forward(x + ff_output)

        return x

    def backward(self, grad):
        grad = self.norm2.backward(grad)

        grad_ff = self.feed_forward.backward(grad)
        grad = grad + grad_ff

        grad = self.norm1.backward(grad)

        grad_attention = self.attention.backward(grad)

        return grad + grad_attention

    def update(self, learning_rate=0.001):
        self.attention.update(learning_rate)
        self.feed_forward.update(learning_rate)

        self.norm1.gamma -= learning_rate * self.norm1.dgamma
        self.norm1.beta -= learning_rate * self.norm1.dbeta

        self.norm2.gamma -= learning_rate * self.norm2.dgamma
        self.norm2.beta -= learning_rate * self.norm2.dbeta