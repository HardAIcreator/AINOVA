import numpy as np


def cross_entropy(logits, targets):
    logits = np.asarray(logits, dtype=np.float64)
    targets = np.asarray(targets, dtype=np.int64)

    logits = logits - np.max(
        logits, axis=-1, keepdims=True
    )

    exp = np.exp(logits)
    probabilities = exp / np.sum(
        exp, axis=-1, keepdims=True
    )

    selected = probabilities[
        np.arange(len(targets)), targets
    ]

    loss = -np.mean(np.log(selected + 1e-12))

    return loss