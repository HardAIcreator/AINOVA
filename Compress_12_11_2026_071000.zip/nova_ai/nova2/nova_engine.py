
import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))

from generate_v31 import load_nova

MAX_NEW_TOKENS = 100
TEMPERATURE = 0.8
TOP_K = 20
REPETITION_PENALTY = 1.2


class NovaEngine:

    def __init__(self):
        print("NOVA AI: Loading model...")

        self.model, self.tokenizer = load_nova()
        self.rng = np.random.default_rng()

        print("NOVA AI: Model loaded!")
        print("Vocabulary:", len(self.tokenizer.vocab))

    def reply(self, prompt):

        token_ids = self.tokenizer.encode(prompt)

        if not token_ids:
            return "Пожалуйста, напиши сообщение."

        initial_length = len(token_ids)

        for _ in range(MAX_NEW_TOKENS):

            context = token_ids[-128:]

            probabilities = self.model.predict(
                np.asarray(context, dtype=np.int64)
            ).astype(np.float64)

            logits = np.log(probabilities + 1e-12)

            recent = set(token_ids[-30:])

            for token in recent:
                if token != 0:
                    logits[token] -= np.log(
                        REPETITION_PENALTY
                    )

            logits[0] = -1e9
            logits /= TEMPERATURE

            top_indices = np.argsort(logits)[-TOP_K:]

            filtered = np.full_like(logits, -1e9)
            filtered[top_indices] = logits[top_indices]

            filtered -= np.max(filtered)

            probabilities = np.exp(filtered)
            total = probabilities.sum()

            if not np.isfinite(total) or total <= 0:
                break

            probabilities /= total

            next_token = self.rng.choice(
                len(probabilities),
                p=probabilities
            )

            token_ids.append(int(next_token))

        generated_tokens = token_ids[initial_length:]

        return self.tokenizer.decode(generated_tokens)


if __name__ == "__main__":

    nova = NovaEngine()

    print("\nNOVA AI ENGINE TEST")
    print("Напиши exit для выхода.")

    while True:

        prompt = input("\nТы: ").strip()

        if prompt.lower() == "exit":
            break

        if not prompt:
            continue

        try:
            print("\nNOVA:", nova.reply(prompt))

        except Exception as error:
            print("GENERATION ERROR:", repr(error))
