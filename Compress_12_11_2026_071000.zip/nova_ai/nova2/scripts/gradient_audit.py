"""NOVA AI - gradient audit (finite differences).

Read-only: no checkpoint is loaded or saved, no training is run,
no project file is modified, no bytecode is written.
"""
import sys

sys.dont_write_bytecode = True

from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from model.attention import SelfAttention
from model.embeddings import Embeddings
from model.language_model import LanguageModel
from model.loss import cross_entropy
from model.transformer import FeedForward, LayerNorm, TransformerBlock

EPS = 1e-5
ABS_TOL = 1e-6
REL_TOL = 1e-4
SEED = 7
EMBED, HIDDEN, SEQ, VOCAB = 8, 16, 5, 11


def numeric_grad(loss_fn, array):
    grad = np.zeros(array.shape, dtype=np.float64)
    for idx in np.ndindex(*array.shape):
        old = array[idx]
        array[idx] = old + EPS
        loss_plus = loss_fn()
        array[idx] = old - EPS
        loss_minus = loss_fn()
        array[idx] = old
        grad[idx] = (loss_plus - loss_minus) / (2 * EPS)
    return grad


def compare(name, analytic, numeric):
    analytic = np.asarray(analytic, dtype=np.float64)

    if analytic.shape != numeric.shape:
        return {
            "name": name, "ok": False, "finite": True,
            "abs": float("nan"), "rel": float("nan"),
            "note": f"shape {analytic.shape} != {numeric.shape}",
        }

    finite = bool(
        np.all(np.isfinite(analytic)) and np.all(np.isfinite(numeric))
    )
    diff = np.abs(analytic - numeric)
    big = np.maximum(np.abs(analytic), np.abs(numeric))
    rel = diff / np.maximum(big, 1e-6)
    elementwise_ok = diff <= ABS_TOL + REL_TOL * big

    return {
        "name": name,
        "ok": finite and bool(np.all(elementwise_ok)),
        "finite": finite,
        "abs": float(np.max(diff)),
        "rel": float(np.max(rel)),
        "note": "" if finite else "NaN/Inf in gradient",
    }


def check_params(loss_fn, params):
    """params: list of (name, array_used_by_loss_fn, analytic_grad)."""
    out = []
    for name, array, analytic in params:
        analytic = np.array(analytic, dtype=np.float64, copy=True)
        out.append(compare(name, analytic, numeric_grad(loss_fn, array)))
    return out


def check_embeddings(rng):
    emb = Embeddings(VOCAB, EMBED, seed=1)
    ids = np.array([1, 3, 3, 7, 2])
    proj = rng.normal(size=(SEQ, EMBED))

    def loss_fn():
        return float(np.sum(emb.forward(ids) * proj))

    emb.forward(ids)
    emb.backward(proj)
    analytic = emb.dweights.copy()

    return check_params(
        loss_fn, [("Embeddings.weights", emb.weights, analytic)]
    )


def check_layernorm(rng):
    ln = LayerNorm(EMBED)
    ln.gamma = rng.normal(1.0, 0.3, EMBED)
    ln.beta = rng.normal(0.0, 0.3, EMBED)
    x = rng.normal(size=(SEQ, EMBED))
    proj = rng.normal(size=(SEQ, EMBED))

    def loss_fn():
        return float(np.sum(ln.forward(x) * proj))

    ln.forward(x)
    dx = ln.backward(proj)
    dgamma, dbeta = ln.dgamma.copy(), ln.dbeta.copy()

    return check_params(loss_fn, [
        ("LayerNorm.input", x, dx),
        ("LayerNorm.gamma", ln.gamma, dgamma),
        ("LayerNorm.beta", ln.beta, dbeta),
    ])


def check_feedforward(rng):
    ff = FeedForward(EMBED, HIDDEN, seed=3)
    ff.b1[:] = rng.normal(0, 0.1, HIDDEN)
    ff.b2[:] = rng.normal(0, 0.1, EMBED)
    x = rng.normal(size=(SEQ, EMBED))
    proj = rng.normal(size=(SEQ, EMBED))

    def loss_fn():
        return float(np.sum(ff.forward(x) * proj))

    ff.forward(x)
    dx = ff.backward(proj)
    grads = {
        "W1": ff.dW1.copy(), "b1": ff.db1.copy(),
        "W2": ff.dW2.copy(), "b2": ff.db2.copy(),
    }

    return check_params(loss_fn, [
        ("FeedForward.input", x, dx),
        ("FeedForward.W1", ff.W1, grads["W1"]),
        ("FeedForward.b1", ff.b1, grads["b1"]),
        ("FeedForward.W2", ff.W2, grads["W2"]),
        ("FeedForward.b2", ff.b2, grads["b2"]),
    ])


def check_attention(rng):
    att = SelfAttention(EMBED, seed=5)
    x = rng.normal(size=(SEQ, EMBED))
    proj = rng.normal(size=(SEQ, EMBED))

    def loss_fn():
        return float(np.sum(att.forward(x) * proj))

    att.forward(x)
    dx = att.backward(proj)
    grads = {
        "Wq": att.dWq.copy(), "Wk": att.dWk.copy(),
        "Wv": att.dWv.copy(), "Wo": att.dWo.copy(),
    }

    return check_params(loss_fn, [
        ("Attention.input", x, dx),
        ("Attention.Wq", att.Wq, grads["Wq"]),
        ("Attention.Wk", att.Wk, grads["Wk"]),
        ("Attention.Wv", att.Wv, grads["Wv"]),
        ("Attention.Wo", att.Wo, grads["Wo"]),
    ])


def randomize_block(block, rng):
    block.norm1.gamma[:] = rng.normal(1.0, 0.2, EMBED)
    block.norm1.beta[:] = rng.normal(0.0, 0.2, EMBED)
    block.norm2.gamma[:] = rng.normal(1.0, 0.2, EMBED)
    block.norm2.beta[:] = rng.normal(0.0, 0.2, EMBED)
    block.feed_forward.b1[:] = rng.normal(0, 0.1, HIDDEN)
    block.feed_forward.b2[:] = rng.normal(0, 0.1, EMBED)


def block_param_list(block, prefix):
    att, ff = block.attention, block.feed_forward
    return [
        (prefix + "attn.Wq", att.Wq, att.dWq),
        (prefix + "attn.Wk", att.Wk, att.dWk),
        (prefix + "attn.Wv", att.Wv, att.dWv),
        (prefix + "attn.Wo", att.Wo, att.dWo),
        (prefix + "norm1.gamma", block.norm1.gamma, block.norm1.dgamma),
        (prefix + "norm1.beta", block.norm1.beta, block.norm1.dbeta),
        (prefix + "norm2.gamma", block.norm2.gamma, block.norm2.dgamma),
        (prefix + "norm2.beta", block.norm2.beta, block.norm2.dbeta),
        (prefix + "ff.W1", ff.W1, ff.dW1),
        (prefix + "ff.b1", ff.b1, ff.db1),
        (prefix + "ff.W2", ff.W2, ff.dW2),
        (prefix + "ff.b2", ff.b2, ff.db2),
    ]


def check_block(rng):
    block = TransformerBlock(EMBED, HIDDEN, seed=11)
    randomize_block(block, rng)
    x = rng.normal(size=(SEQ, EMBED))
    proj = rng.normal(size=(SEQ, EMBED))

    def loss_fn():
        return float(np.sum(block.forward(x) * proj))

    block.forward(x)
    dx = block.backward(proj)

    params = [("Block.input", x, dx)]
    for name, array, grad in block_param_list(block, "Block."):
        params.append((name, array, grad))

    return check_params(loss_fn, params)


def check_full_model(rng):
    """Chain check: output layer + 2 blocks + embeddings.

    Repeats the gradient formulas of OutputTrainer.train_step,
    but WITHOUT any weight update.
    """
    model = LanguageModel(VOCAB, EMBED, HIDDEN, num_layers=2, seed=42)

    for block in model.blocks:
        randomize_block(block, rng)

    model.output_bias[:] = rng.normal(0, 0.1, VOCAB)
    ids = rng.integers(0, VOCAB, SEQ)
    targets = rng.integers(0, VOCAB, SEQ)

    def loss_fn():
        return float(cross_entropy(model.forward(ids), targets))

    features = model.forward_features(ids)
    logits = features @ model.output_weights + model.output_bias
    logits = logits - np.max(logits, axis=1, keepdims=True)
    probs = np.exp(logits)
    probs /= np.sum(probs, axis=1, keepdims=True)

    grad_logits = probs.copy()
    grad_logits[np.arange(len(targets)), targets] -= 1
    grad_logits /= len(targets)

    grad_w = features.T @ grad_logits
    grad_b = np.sum(grad_logits, axis=0)
    grad_features = grad_logits @ model.output_weights.T

    for block in reversed(model.blocks):
        grad_features = block.backward(grad_features)

    model.embeddings.backward(grad_features)

    params = [
        ("Model.output_weights", model.output_weights, grad_w),
        ("Model.output_bias", model.output_bias, grad_b),
        ("Model.embeddings", model.embeddings.weights,
         model.embeddings.dweights),
    ]

    for i, block in enumerate(model.blocks):
        params.extend(block_param_list(block, f"Model.block{i}."))

    return check_params(loss_fn, params)


COMPONENTS = [
    ("Embeddings", check_embeddings),
    ("LayerNorm", check_layernorm),
    ("FeedForward", check_feedforward),
    ("Attention", check_attention),
    ("TransformerBlock", check_block),
    ("Full model chain", check_full_model),
]


def main():
    print("NOVA AI - GRADIENT AUDIT")
    print(f"seed={SEED} eps={EPS} abs_tol={ABS_TOL} rel_tol={REL_TOL}")
    print(f"embed={EMBED} hidden={HIDDEN} seq={SEQ} vocab={VOCAB}")

    summary = []
    problems = []

    for title, fn in COMPONENTS:
        print("\n== " + title)
        rng = np.random.default_rng(SEED)

        try:
            results = fn(rng)
        except Exception as error:
            print("  [ERROR]", repr(error))
            summary.append((title, False))
            problems.append(f"{title}: exception {error!r}")
            continue

        for r in results:
            tag = "PASS" if r["ok"] else "FAIL"
            line = (
                f"  [{tag}] {r['name']:<24} "
                f"abs={r['abs']:.2e} rel={r['rel']:.2e}"
            )
            if r["note"]:
                line += "  " + r["note"]
            print(line)

            if not r["ok"]:
                problems.append(
                    f"{r['name']}: abs={r['abs']:.2e} "
                    f"rel={r['rel']:.2e} {r['note']}".strip()
                )

        summary.append((title, all(r["ok"] for r in results)))

    print("\n==== SUMMARY")
    for title, ok in summary:
        print(f"  {'PASS' if ok else 'FAIL'}  {title}")

    overall = all(ok for _, ok in summary)
    print("\nOVERALL:", "PASS" if overall else "FAIL")

    print("\nPROBLEMS:")
    if problems:
        for p in problems:
            print("  -", p)
    else:
        print("  none")


if __name__ == "__main__":
    main()