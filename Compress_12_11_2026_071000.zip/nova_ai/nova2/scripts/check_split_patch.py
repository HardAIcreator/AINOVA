from pathlib import Path
import time

p = Path("/storage/emulated/0/nova_ai/nova2/scripts/build_corpus.py")
text = p.read_text(encoding="utf-8")

print("modified:", time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(p.stat().st_mtime)))
print("has VAL_SHARE:", "VAL_SHARE" in text)
print("has VAL_PERCENT:", "VAL_PERCENT" in text)
print("assign_splits definitions:", text.count("def assign_splits"))

for i, line in enumerate(text.splitlines(), 1):
    if "VAL_SHARE" in line or "VAL_PERCENT" in line:
        print(i, line.strip())