
import sys
from pathlib import Path
import numpy as np

ROOT = Path("/storage/emulated/0/nova_ai/nova2")
sys.path.insert(0, str(ROOT))

from model.tokenizer import BPETokenizer
from model.language_model import LanguageModel

CHECKPOINTS = ROOT / "checkpoints_v31"

EMBED_SIZE = 64
HIDDEN_SIZE = 256
NUM_LAYERS = 2

MAX_NEW_TOKENS = 100
TEMPERATURE = 0.8
TOP_K = 20
REPETITION_PENALTY = 1.2


def load_nova():
    tokenizer = BPETokenizer()
    tokenizer.load(
        str(CHECKPOINTS / "best_tokenizer.json")
    )

    model = LanguageModel(
        vocab_size=len(tokenizer.vocab),
        embed_size=EMBED_SIZE,
        hidden_size=HIDDEN_SIZE,
        num_layers=NUM_LAYERS
    )

    model.load(
        str(CHECKPOINTS / "best_model.npz")
    )

    return model, tokenizer


def generate(model, tokenizer, prompt):
    token_ids = tokenizer.encode(prompt)

    if not token_ids:
        raise ValueError("Empty prompt")

    rng = np.random.default_rng()

    for _ in range(MAX_NEW_TOKENS):
        context = token_ids[-128:]

        probabilities = model.predict(
            np.asarray(context, dtype=np.int64)
        ).astype(np.float64)

        logits = np.log(probabilities + 1e-12)

        recent = set(token_ids[-30:])

        for token in recent:
            if token != 0:
                logits[token] -= np.log(REPETITION_PENALTY)

        logits[0] = -1e9
        logits /= TEMPERATURE

        top_indices = np.argsort(logits)[-TOP_K:]

        filtered = np.full_like(logits, -1e9)
        filtered[top_indices] = logits[top_indices]

        filtered -= np.max(filtered)
        probabilities = np.exp(filtered)
        total = probabilities.sum()

        if not np.isfinite(total) or total <= 0:
            break

        probabilities /= total

        next_token = rng.choice(
            len(probabilities),
            p=probabilities
        )

        token_ids.append(int(next_token))

    return tokenizer.decode(token_ids)


def main():
    print("NOVA AI 3.2 — BEST MODEL GENERATOR")
    print("Loading best checkpoint...")

    model, tokenizer = load_nova()

    print("BEST MODEL LOADED")
    print("Vocabulary:", len(tokenizer.vocab))
    print("Max new tokens:", MAX_NEW_TOKENS)
    print()
    print("Напиши exit для выхода.")

    while True:
        prompt = input("\nТы: ").strip()

        if prompt.lower() == "exit":
            break

        if not prompt:
            continue

        try:
            result = generate(model, tokenizer, prompt)
            print("\nNOVA:", result)

        except ValueError as error:
            print("INPUT ERROR:", error)

    print("\nNOVA AI 3.2 SESSION CLOSED")


if __name__ == "__main__":
    main()
