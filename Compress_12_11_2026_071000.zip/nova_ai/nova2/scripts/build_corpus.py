"""NOVA AI - step 2: Wikipedia corpus builder (ru / kk / en).

Standard library only. Writes ONLY into data_v2/.
Does not train and does not touch the model, tokenizer or old data.
"""
import hashlib
import json
import os
import re
import sys
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

# ======================= SETTINGS (edit here) =======================
MODE = "full"                # "test" = few articles, "full" = grow
CONTACT = "rgunchevskij@gmail.com"    # PUT YOUR REAL E-MAIL (Wikimedia rule)
LANGS = ["ru", "kk", "en"]
TEST_DOCS_PER_LANG = 3
TARGET_KB_PER_LANG = 100              # UTF-8 KB of clean text per language
MAX_RUNTIME_MIN = 30                  # total time budget for one run
MAX_REQUESTS_PER_LANG = 300
REQUEST_PAUSE = 1.0                   # seconds between requests
TIMEOUT = 25
MAX_RETRIES = 4
MAX_FAILS_IN_ROW = 5

MIN_DOC_CHARS = 800
MAX_DOC_CHARS = 2500
MIN_PARAGRAPH_CHARS = 60
MIN_WIKITEXT_BYTES = 3000             # skip tiny stubs before downloading
VAL_SHARE = 0.10                      # share of characters kept for validation
MIN_LETTER_SHARE = 0.5                # drop number-heavy lines (tables)
# ====================================================================

ROOT = Path("/storage/emulated/0/nova_ai/nova2")
OUT = ROOT / "data_v2"

LICENSE = "CC BY-SA 4.0"
LICENSE_URL = "https://creativecommons.org/licenses/by-sa/4.0/"

STOP_SECTIONS = {
    "ru": {"примечания", "ссылки", "литература", "см. также",
           "источники", "внешние ссылки"},
    "kk": {"дереккөздер", "дереккөз", "сілтемелер", "әдебиет",
           "сыртқы сілтемелер", "ескертпелер", "дерек көздері",
           "сондай-ақ қараңыз"},
    "en": {"references", "external links", "further reading", "see also",
           "notes", "bibliography", "sources", "footnotes"},
}

KK_SPECIFIC = set("әғқңөұүһіӘҒҚҢӨҰҮҺІ")
ZERO_WIDTH = ["\u200b", "\u200c", "\u200d", "\ufeff", "\u00ad", "\u0301"]

HEADER_RE = re.compile(r"^=+\s*(.*?)\s*=+$")
CITE_RE = re.compile(
    r"\[\s*(?:\d+|[a-z]|citation needed|нужен источник|дереккөз керек)\s*\]",
    re.I,
)
TAG_RE = re.compile(r"<[^>]{1,200}>")
TEMPLATE_RE = re.compile(r"\{\{[^{}]*\}\}|\{\|.*?\|\}", re.S)
EMPTY_PAREN_RE = re.compile(r"\(\s*[,;:\-\u2013\u2014\s]*\)")
SPACE_RE = re.compile(r"[ \t\u00a0\u2009\u202f]+")
REPEAT_RE = re.compile(r"(.)\1{9,}")
SENT_SPLIT_RE = re.compile(
    r"(?<=[.!?\u2026])\s+(?=[A-ZА-ЯЁӘҒҚҢӨҰҮҺІ\u00ab\u201c\"(0-9])"
)
DIGITS = set("0123456789")
ALLOWED_PUNCT = set(".,;:!?()-–—'’‘\"«»“”„%/&№°$€£+=·…")
CHAR_MAP = str.maketrans({
    "\u2212": "-", "\u2010": "-", "\u2011": "-", "\u2012": "-",
    "\u2015": "\u2014",
    "\u02bb": "\u2019", "\u02bc": "\u2019", "\u00b4": "\u2019",
    "`": "\u2019",
})


class ApiError(Exception):
    pass


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def user_agent():
    return (
        f"NovaAI-CorpusBuilder/1.0 (educational research; "
        f"contact: {CONTACT}) python-urllib"
    )


# ------------------------------ network ------------------------------

def retry_after(error):
    try:
        value = int(error.headers.get("Retry-After", ""))
        return min(max(value, 1), 60)
    except (TypeError, ValueError, AttributeError):
        return None


def api_get(lang, params):
    params = dict(params)
    params.update(
        {"format": "json", "formatversion": "2", "maxlag": "5"}
    )
    url = (
        f"https://{lang}.wikipedia.org/w/api.php?"
        + urllib.parse.urlencode(params)
    )
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": user_agent(),
            "Accept": "application/json",
        },
    )

    delay = 2.0
    last = None

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            with urllib.request.urlopen(request, timeout=TIMEOUT) as resp:
                data = json.loads(resp.read().decode("utf-8"))

            if "error" in data:
                code = data["error"].get("code", "")
                if code == "maxlag":
                    last = ApiError("maxlag")
                    print(f"  server busy (maxlag), wait {delay:.0f}s")
                    time.sleep(delay)
                    delay *= 2
                    continue
                info = data["error"].get("info", "")
                raise ApiError(f"API error {code}: {info}")

            return data

        except urllib.error.HTTPError as error:
            last = error
            if error.code in (429, 500, 502, 503, 504):
                wait = retry_after(error) or delay
                print(f"  HTTP {error.code}, retry {attempt}, wait {wait:.0f}s")
                time.sleep(wait)
                delay *= 2
                continue
            raise ApiError(f"HTTP {error.code}")

        except (urllib.error.URLError, OSError, ValueError) as error:
            last = error
            print(f"  network problem ({error!r}), retry {attempt}")
            time.sleep(delay)
            delay *= 2

    raise ApiError(f"failed after {MAX_RETRIES} tries: {last!r}")


def random_candidates(lang):
    data = api_get(lang, {
        "action": "query",
        "generator": "random",
        "grnnamespace": "0",
        "grnlimit": "20",
        "prop": "revisions",
        "rvprop": "size|ids",
    })
    pages = data.get("query", {}).get("pages", [])
    result = []

    for page in pages:
        revisions = page.get("revisions") or [{}]
        size = revisions[0].get("size")
        if size is not None and size < MIN_WIKITEXT_BYTES:
            continue
        if page.get("pageid") and page.get("title"):
            result.append((page["pageid"], page["title"]))

    return result, len(pages)


def fetch_article(lang, title):
    data = api_get(lang, {
        "action": "query",
        "titles": title,
        "prop": "extracts|info|revisions",
        "explaintext": "1",
        "exsectionformat": "wiki",
        "inprop": "url",
        "rvprop": "ids",
        "redirects": "1",
    })
    pages = data.get("query", {}).get("pages", [])

    if not pages:
        return None

    page = pages[0]
    if page.get("missing") or not page.get("extract"):
        return None

    revisions = page.get("revisions") or [{}]
    quoted = urllib.parse.quote(page.get("title", title).replace(" ", "_"))

    return {
        "pageid": page.get("pageid"),
        "title": page.get("title", title),
        "url": page.get("fullurl")
        or f"https://{lang}.wikipedia.org/wiki/{quoted}",
        "revid": revisions[0].get("revid"),
        "extract": page["extract"],
    }


# ------------------------------ cleaning ------------------------------

def letter_script(ch):
    name = unicodedata.name(ch, "")
    if name.startswith("CYRILLIC"):
        return "cyr"
    if name.startswith("LATIN"):
        return "lat"
    return "other"


def script_shares(text):
    counts = {"cyr": 0, "lat": 0, "other": 0}
    for ch in text:
        if ch.isalpha():
            counts[letter_script(ch)] += 1

    total = sum(counts.values())
    if total == 0:
        return None

    return {k: v / total for k, v in counts.items()}, total


def has_disallowed(text):
    for ch in text:
        if ch == " " or ch in DIGITS or ch in ALLOWED_PUNCT:
            continue
        if ch.isalpha() and letter_script(ch) != "other":
            continue
        return True
    return False


def soften_paragraph(par, note=None):
    """Drop only the sentences that contain unsupported symbols.

    If more than half of the paragraph would be lost (formulas, markup),
    the whole paragraph is dropped.
    """
    if not has_disallowed(par):
        return par

    sentences = SENT_SPLIT_RE.split(par)
    kept = [s for s in sentences if not has_disallowed(s)]
    text = " ".join(kept)

    if not kept or len(text) < 0.5 * len(par):
        if note:
            note("para_dropped_symbols")
        return ""

    if note:
        note("sentence_dropped_symbols", len(sentences) - len(kept))
    return text


def paragraph_ok(par, lang):
    if len(par) < MIN_PARAGRAPH_CHARS:
        return False
    if REPEAT_RE.search(par):
        return False

    info = script_shares(par)
    if info is None:
        return False

    shares, letters = info

    if letters / len(par) < MIN_LETTER_SHARE:
        return False
    if shares["other"] > 0.05:
        return False
    if lang in ("ru", "kk") and shares["cyr"] < 0.7:
        return False
    if lang == "en" and shares["lat"] < 0.9:
        return False

    return True


def clean_paragraphs(raw, lang, note=None):
    raw = unicodedata.normalize("NFC", raw).replace("\r", "\n")

    for ch in ZERO_WIDTH:
        raw = raw.replace(ch, "")

    raw = TEMPLATE_RE.sub(" ", raw)
    raw = TAG_RE.sub(" ", raw)
    raw = CITE_RE.sub("", raw)

    stops = STOP_SECTIONS.get(lang, set())
    paragraphs = []

    for line in raw.split("\n"):
        line = line.strip()
        if not line:
            continue

        header = HEADER_RE.match(line)
        if header:
            if header.group(1).strip().lower() in stops:
                break
            continue

        line = SPACE_RE.sub(" ", line).translate(CHAR_MAP)
        line = EMPTY_PAREN_RE.sub("", line)
        line = re.sub(r"\s+([,.;:!?])", r"\1", line)
        line = SPACE_RE.sub(" ", line).strip()
        line = soften_paragraph(line, note)

        if paragraph_ok(line, lang):
            paragraphs.append(line)
        elif note and line:
            note("para_dropped_other")

    seen = set()
    unique = []
    for par in paragraphs:
        key = par.lower()
        if key not in seen:
            seen.add(key)
            unique.append(par)

    return unique


def build_text(paragraphs):
    out = []
    total = 0

    for par in paragraphs:
        if total + len(par) + 1 > MAX_DOC_CHARS:
            if not out:
                cut = par[:MAX_DOC_CHARS]
                end = max(cut.rfind(". "), cut.rfind("! "), cut.rfind("? "))
                if end > MIN_PARAGRAPH_CHARS:
                    out.append(cut[: end + 1])
            break
        out.append(par)
        total += len(par) + 1

    return "\n".join(out)


def quality_problem(text, lang):
    if len(text) < MIN_DOC_CHARS:
        return "too_short"

    info = script_shares(text)
    if info is None:
        return "no_letters"

    _, letters = info
    kk_share = sum(1 for ch in text if ch in KK_SPECIFIC) / letters

    if lang == "kk" and kk_share < 0.01:
        return "not_kazakh"
    if lang == "ru" and kk_share > 0.01:
        return "not_russian"

    words = text.lower().split()
    if len(set(words)) / max(1, len(words)) < 0.35:
        return "repetitive"

    return None


# ------------------------------ storage ------------------------------

def load_existing():
    path = OUT / "documents.jsonl"
    docs = []

    if path.exists():
        with path.open("r", encoding="utf-8") as file:
            for line in file:
                line = line.strip()
                if not line:
                    continue
                try:
                    docs.append(json.loads(line))
                except json.JSONDecodeError:
                    print("  skipped a broken line in documents.jsonl")

    return docs


def append_doc(doc):
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "documents.jsonl"

    # if a previous run died in the middle of a line, start a fresh line
    needs_newline = False
    if path.exists() and path.stat().st_size > 0:
        with path.open("rb") as check:
            check.seek(-1, os.SEEK_END)
            needs_newline = check.read(1) != b"\n"

    with path.open("a", encoding="utf-8") as file:
        if needs_newline:
            file.write("\n")
        file.write(json.dumps(doc, ensure_ascii=False) + "\n")
        file.flush()


def write_atomic(path, text):
    tmp = path.parent / (path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def doc_hash(doc):
    key = f"{doc['lang']}|{doc['title']}".encode("utf-8")
    return hashlib.md5(key).hexdigest()


def assign_splits(docs):
    """Per language: lowest-hash documents go to validation until they
    cover about VAL_SHARE of the language's characters."""
    for doc in docs:
        doc["split"] = "train"

    for lang in sorted({d["lang"] for d in docs}):
        group = sorted(
            (d for d in docs if d["lang"] == lang), key=doc_hash
        )
        if len(group) < 2:
            continue

        budget = VAL_SHARE * sum(len(d["text"]) for d in group)
        used = 0
        for doc in group:
            if used < budget:
                doc["split"] = "validation"
                used += len(doc["text"])

        if not any(d["split"] == "train" for d in group):
            group[-1]["split"] = "train"


def language_report(docs, lang, rejected):
    group = [d for d in docs if d["lang"] == lang]
    lines = [f"=== {lang} ==="]

    if not group:
        return lines + ["no documents", ""], 0, 0, 0

    train = [d for d in group if d["split"] == "train"]
    val = [d for d in group if d["split"] == "validation"]
    all_text = "\n".join(d["text"] for d in group)
    chars = len(all_text)
    size = len(all_text.encode("utf-8"))
    words = len(all_text.split())

    lines.append(f"documents: train {len(train)} / validation {len(val)}")
    lines.append(
        "characters: train "
        f"{sum(len(d['text']) for d in train)} / validation "
        f"{sum(len(d['text']) for d in val)}"
    )
    lines.append(f"size UTF-8: {size / 1024:.1f} KB, words: {words}")
    lines.append(f"avg document: {chars // len(group)} characters")

    info = script_shares(all_text)
    if info:
        shares, letters = info
        kk_share = sum(1 for c in all_text if c in KK_SPECIFIC) / letters
        lines.append(
            f"letters: Cyrillic {shares['cyr'] * 100:.1f}% "
            f"Latin {shares['lat'] * 100:.1f}% "
            f"other {shares['other'] * 100:.1f}%"
        )
        lines.append(f"Kazakh-specific letters: {kk_share * 100:.2f}%")

    counter = Counter(all_text)
    rare = "".join(
        ch for ch, n in counter.items() if n < 3 and not ch.isspace()
    )
    lines.append(f"unique characters: {len(counter)}")
    lines.append(f"rare characters (<3 times): {rare[:60] or '-'}")

    if rejected:
        text = ", ".join(f"{k}={v}" for k, v in sorted(rejected.items()))
        lines.append(f"rejected in this run: {text}")

    lines.append("")
    return lines, len(group), chars, size


def rebuild_outputs(docs, rejections):
    OUT.mkdir(parents=True, exist_ok=True)
    assign_splits(docs)

    train = "\n\n".join(d["text"] for d in docs if d["split"] == "train")
    val = "\n\n".join(d["text"] for d in docs if d["split"] == "validation")
    write_atomic(OUT / "train.txt", train + "\n" if train else "")
    write_atomic(OUT / "validation.txt", val + "\n" if val else "")

    rows = ["lang\tsplit\ttitle\turl\tpermalink\tlicense\tlicense_url"
            "\tretrieved_utc\tchars"]
    for d in docs:
        rows.append("\t".join([
            d["lang"], d["split"], d["title"].replace("\t", " "),
            d.get("url", ""), d.get("permalink", ""), d.get("license", ""),
            d.get("license_url", ""), d.get("retrieved_utc", ""),
            str(d.get("chars", len(d["text"]))),
        ]))
    write_atomic(OUT / "SOURCES.tsv", "\n".join(rows) + "\n")

    notice = (
        "Texts in this corpus come from Wikipedia (ru, kk, en) via the "
        "MediaWiki API.\n"
        f"License of the texts: {LICENSE} - {LICENSE_URL}\n"
        "Attribution: SOURCES.tsv lists article title, URL and permanent "
        "link of every document.\n"
        "Changes made: section headers, references, templates and short "
        "or non-text lines were removed; long articles were truncated.\n"
        "Check the license terms before publishing or redistributing the "
        "corpus or derived data.\n"
    )
    write_atomic(OUT / "LICENSE_NOTICE.txt", notice)

    report = [
        "NOVA AI - corpus report (data_v2)",
        f"generated: {now_iso()}",
        f"mode: {MODE}",
        "",
    ]
    total_docs = total_chars = total_size = 0

    for lang in sorted({d["lang"] for d in docs} | set(LANGS)):
        lines, n, chars, size = language_report(
            docs, lang, rejections.get(lang, {})
        )
        report.extend(lines)
        total_docs += n
        total_chars += chars
        total_size += size

    report.append(
        f"TOTAL: {total_docs} documents, {total_chars} characters, "
        f"{total_size / 1024:.1f} KB"
    )
    text = "\n".join(report) + "\n"
    write_atomic(OUT / "corpus_report.txt", text)
    return text


# ------------------------------ collecting ------------------------------

def reject(rejections, lang, reason, count=1):
    bucket = rejections.setdefault(lang, {})
    bucket[reason] = bucket.get(reason, 0) + count


def lang_docs(docs, lang):
    return [d for d in docs if d["lang"] == lang]


def lang_done(docs, lang):
    group = lang_docs(docs, lang)
    if MODE == "test":
        return len(group) >= TEST_DOCS_PER_LANG
    size = sum(len(d["text"].encode("utf-8")) for d in group)
    return size / 1024 >= TARGET_KB_PER_LANG


def collect_language(lang, docs, rejections, deadline):
    seen_ids = {d["id"] for d in docs}
    seen_texts = {hashlib.md5(d["text"].encode("utf-8")).hexdigest()
                  for d in docs}
    requests = 0
    fails = 0

    while not lang_done(docs, lang):
        if time.time() > deadline:
            print(f"[{lang}] time limit reached")
            return
        if requests >= MAX_REQUESTS_PER_LANG:
            print(f"[{lang}] request limit reached")
            return
        if fails >= MAX_FAILS_IN_ROW:
            print(f"[{lang}] too many errors, skipping language")
            return

        try:
            candidates, listed = random_candidates(lang)
            requests += 1
            fails = 0
            reject(rejections, lang, "stub_skipped", listed - len(candidates))
        except ApiError as error:
            fails += 1
            requests += 1
            print(f"[{lang}] list error: {error}")
            time.sleep(REQUEST_PAUSE)
            continue

        time.sleep(REQUEST_PAUSE)

        for pageid, title in candidates:
            if lang_done(docs, lang) or time.time() > deadline:
                break

            doc_id = f"{lang}:{pageid}"
            if doc_id in seen_ids:
                reject(rejections, lang, "already_have")
                continue

            try:
                article = fetch_article(lang, title)
                requests += 1
                fails = 0
            except ApiError as error:
                fails += 1
                requests += 1
                print(f"[{lang}] fetch error ({title}): {error}")
                reject(rejections, lang, "fetch_error")
                time.sleep(REQUEST_PAUSE)
                if fails >= MAX_FAILS_IN_ROW:
                    break
                continue

            time.sleep(REQUEST_PAUSE)

            if article is None:
                reject(rejections, lang, "empty")
                continue

            def note(reason, count=1, lang=lang):
                reject(rejections, lang, reason, count)

            text = build_text(
                clean_paragraphs(article["extract"], lang, note)
            )
            problem = quality_problem(text, lang)

            if problem:
                reject(rejections, lang, problem)
                continue

            digest = hashlib.md5(text.encode("utf-8")).hexdigest()
            if digest in seen_texts:
                reject(rejections, lang, "duplicate")
                continue

            permalink = (
                f"https://{lang}.wikipedia.org/w/index.php?"
                f"oldid={article['revid']}"
                if article["revid"] else article["url"]
            )
            doc = {
                "id": doc_id,
                "lang": lang,
                "title": article["title"],
                "pageid": article["pageid"],
                "revid": article["revid"],
                "url": article["url"],
                "permalink": permalink,
                "license": LICENSE,
                "license_url": LICENSE_URL,
                "retrieved_utc": now_iso(),
                "chars": len(text),
                "text": text,
            }

            append_doc(doc)
            docs.append(doc)
            seen_ids.add(doc_id)
            seen_texts.add(digest)
            print(f"[{lang}] + {article['title']} ({len(text)} chars)")


def main():
    if "example.com" in CONTACT:
        print("Set CONTACT at the top of the script to your real e-mail.")
        print("Wikimedia requires an identifying User-Agent with contact.")
        return

    OUT.mkdir(parents=True, exist_ok=True)
    docs = load_existing()
    rejections = {}

    print("NOVA AI - CORPUS BUILDER")
    print(f"mode={MODE} output={OUT}")
    print(f"documents already in data_v2: {len(docs)}")

    slice_seconds = MAX_RUNTIME_MIN * 60 / max(1, len(LANGS))

    try:
        for lang in LANGS:
            if lang_done(docs, lang):
                print(f"[{lang}] target already reached")
                continue
            print(f"\n[{lang}] collecting...")
            collect_language(
                lang, docs, rejections, time.time() + slice_seconds
            )
    except KeyboardInterrupt:
        print("\nStopped by user, saving what was collected.")

    print()
    print(rebuild_outputs(docs, rejections))
    print("Files are in:", OUT)


if __name__ == "__main__":
    main()