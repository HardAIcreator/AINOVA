
import os

BASE = "/storage/emulated/0/nova_ai/nova2"
os.chdir(BASE)

files = [
    "scripts/generate_v31.py",
    "scripts/generate.py",
    "chat.py",
    "model/tokenizer.py"
]

for path in files:
    print("\n" + "=" * 50)
    print("FILE:", path)
    print("=" * 50)

    if not os.path.exists(path):
        print("FILE NOT FOUND")
        continue

    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    print(content[:15000])

print("\nINSPECTION COMPLETE")
