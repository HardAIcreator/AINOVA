from pathlib import Path

path = Path("/storage/emulated/0/nova_ai/nova2/scripts/train.py")

code = path.read_text(encoding="utf-8")

old = "tokenizer.fit([train_text], vocab_size=500)"
new = "tokenizer.fit([train_text, validation_text], vocab_size=500)"

if old not in code:
    print("Строка не найдена!")
else:
    code = code.replace(old, new)
    path.write_text(code, encoding="utf-8")
    print("TOKENIZER FIXED:", new in code)