from pathlib import Path

path = Path("/storage/emulated/0/nova_ai/nova2/model/tokenizer.py")

code = r'''
import json
import re
from collections import Counter


class BPETokenizer:
    def __init__(self):
        self.vocab = {}
        self.merges = []
        self.unk_token = "<unk>"

    def fit(self, texts, vocab_size=500):
        sequences = []

        for text in texts:
            words = re.findall(r"\w+|[^\w\s]|\s+", text.lower())
            sequences.extend([list(word) for word in words])

        alphabet = set()
        for seq in sequences:
            alphabet.update(seq)

        self.vocab = {self.unk_token: 0}

        for token in sorted(alphabet):
            self.vocab[token] = len(self.vocab)

        self.merges = []

        while len(self.vocab) < vocab_size:
            pairs = Counter()

            for seq in sequences:
                for i in range(len(seq) - 1):
                    pairs[(seq[i], seq[i + 1])] += 1

            if not pairs:
                break

            pair, frequency = pairs.most_common(1)[0]

            if frequency < 2:
                break

            merged = pair[0] + pair[1]

            self.merges.append(pair)

            updated = []

            for seq in sequences:
                result = []
                i = 0

                while i < len(seq):
                    if (
                        i + 1 < len(seq)
                        and (seq[i], seq[i + 1]) == pair
                    ):
                        result.append(merged)
                        i += 2
                    else:
                        result.append(seq[i])
                        i += 1

                updated.append(result)

            sequences = updated
            self.vocab[merged] = len(self.vocab)

    def encode(self, text):
        words = re.findall(r"\w+|[^\w\s]|\s+", text.lower())
        result = []

        for word in words:
            seq = list(word)

            for pair in self.merges:
                merged = pair[0] + pair[1]
                updated = []
                i = 0

                while i < len(seq):
                    if (
                        i + 1 < len(seq)
                        and (seq[i], seq[i + 1]) == pair
                    ):
                        updated.append(merged)
                        i += 2
                    else:
                        updated.append(seq[i])
                        i += 1

                seq = updated

            for token in seq:
                if token not in self.vocab:
                    raise ValueError(
                        "Unknown character: " + repr(token)
                    )
                result.append(self.vocab[token])

        return result

    def decode(self, tokens):
        inverse = {
            i: token for token, i in self.vocab.items()
        }

        return "".join(inverse[token] for token in tokens)

    def save(self, path):
        data = {
            "vocab": self.vocab,
            "merges": self.merges
        }

        with open(path, "w", encoding="utf-8") as file:
            json.dump(data, file, ensure_ascii=False, indent=2)

    def load(self, path):
        with open(path, "r", encoding="utf-8") as file:
            data = json.load(file)

        self.vocab = data["vocab"]
        self.merges = [
            tuple(pair) for pair in data["merges"]
        ]
'''


path.write_text(code.strip() + "\n", encoding="utf-8")

print("NOVA AI — TOKENIZER FIX")
print("Файл заменён:", path.exists())
print("Размер:", path.stat().st_size)

import sys
sys.path.insert(0, "/storage/emulated/0/nova_ai/nova2")

from model.tokenizer import BPETokenizer

tokenizer = BPETokenizer()

tokenizer.fit([
    "привет nova",
    "я изучаю программирование",
    "искусственный интеллект"
], vocab_size=100)

tests = [
    "привет nova",
    "я изучаю программирование",
    "искусственный интеллект"
]

print("\nROUND TRIP TEST")

for original in tests:
    decoded = tokenizer.decode(tokenizer.encode(original))
    passed = decoded == original

    print("Исходный:", original)
    print("Результат:", decoded)
    print("PASS:", passed)

print("\nUNKNOWN CHARACTER TEST")

try:
    tokenizer.encode("привет🙂")
except ValueError as error:
    print("Обнаружен неизвестный символ:", error)

print("\nTOKENIZER FIX COMPLETE")