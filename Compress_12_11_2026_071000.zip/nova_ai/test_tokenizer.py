import sys
sys.path.insert(0, "/storage/emulated/0/nova_ai/nova2")

from model.tokenizer import BPETokenizer

tokenizer = BPETokenizer()

tokenizer.fit([
    "привет nova",
    "я изучаю программирование",
    "искусственный интеллект"
], vocab_size=100)

text = "привет, nova! это новый текст?"

tokens = tokenizer.encode(text)

print("NOVA AI — TOKENIZER TEST 2")
print("Словарь:", len(tokenizer.vocab))
print("Токены:", tokens)
print("Декодирование:", tokenizer.decode(tokens))
print("Неизвестный токен:", tokenizer.vocab["<unk>"])
print("TEST COMPLETE")